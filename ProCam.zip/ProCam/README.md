# ProCam – Pro Video Camera for Android

Manual video camera (Camera2): ISO, shutter, focus, white balance, EV, zoom,
resolution, frame rate, aspect ratio, codec, bitrate, lens switching, grid, stabilization.
Videos are saved to Movies/ProCam. Requires Android 8.0+ and a device with Camera2 manual support.

## Get the APK (pick one)

### A) GitHub (no installs, ~5 min)
1. Create a new repo on github.com, upload everything in this folder (keep `.github/`).
2. Open the **Actions** tab -> "Build APK" -> wait for green check.
3. Open the run -> **Artifacts** -> download `ProCam-apk`, unzip, install `app-release.apk`.

### B) Android Studio
Open this folder -> wait for Gradle sync -> Build > Build APK(s)
(or run `gradle assembleRelease`). APK: `app/build/outputs/apk/release/app-release.apk`

## Using it
- Bottom tabs: ISO / SHUTTER / FOCUS / WB / EV / ZOOM. Tap a tab, drag the dial.
- AUTO button returns the selected control to automatic. ISO + shutter switch to manual together.
- Top chips: resolution, fps, aspect ratio, codec, bitrate, grid, stabilization.
- Right: lens selector (ultra-wide / main / tele), timer, record button.
- Tap the preview to set the autofocus point.
