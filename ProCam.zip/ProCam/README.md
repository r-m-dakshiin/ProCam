# ProCam – Pro Video Camera for Android

Manual video camera (Camera2): ISO, shutter, focus, white balance, EV, zoom,
resolution, frame rate, aspect ratio, codec, bitrate, lens switching, grid, stabilization (OFF / OIS / EIS; OIS is on by default).
Videos are saved to Movies/ProCam. Requires Android 8.0+ and a device with Camera2 manual support.

## Get the APK (pick one)

### A) GitHub (no installs, ~5 min)
1. Create a new repo on github.com, upload everything in this folder (keep `.github/`).
2. Open the **Actions** tab -> "Build APK" -> wait for green check.
3. Open the run -> **Artifacts** -> download `ProCam-apk`, unzip, install `app-release.apk`.

### B) Android Studio
Open this folder -> wait for Gradle sync -> Build > Build APK(s)
(or run `gradle assembleRelease`). APK: `app/build/outputs/apk/release/app-release.apk`

## Using it
- Bottom tabs: ISO / SHUTTER / FOCUS / WB / EV / ZOOM. Tap a tab, drag the dial.
- AUTO button returns the selected control to automatic. ISO + shutter switch to manual together.
- Top chips: resolution, fps, aspect ratio, codec, bitrate, grid, stabilization (OFF / OIS / EIS; OIS is on by default).
- Right: lens selector (ultra-wide / main / tele), timer, record button.
- Tap the preview to set the autofocus point.

## Log / 10-bit / LUT (new)
- Video now goes camera -> OpenGL -> MediaCodec + MediaMuxer (no MediaRecorder), so 4K60 and HEVC Main10 are possible.
- **LOG** chip: S-LOG3, LOGC3 (log curves, Rec.709 primaries) or HLG (BT.2020 + HLG tags). The file is always recorded in the chosen log curve.
- **10-BIT** chip: HEVC Main10 (needs encoder + EGL 10-bit surface support; falls back to 8-bit automatically).
- **LUT** chip: monitoring only, the LUT is applied to the preview but never baked into the recording. OFF shows the flat log image, REC.709 is a built-in log->709 view, "+ IMPORT" adds a 3D `.cube` LUT (up to 65^3). LUTs can be switched while recording; import them before you start.
- 60 fps appears in the FPS chip when the camera reports it for the chosen resolution.
