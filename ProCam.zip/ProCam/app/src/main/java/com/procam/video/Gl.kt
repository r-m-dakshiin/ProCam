package com.procam.video

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLES30
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** 3D LUT: [n]^3 RGB triplets, red index changes fastest (.cube order). */
class LutData(val n: Int, val rgb: FloatArray)

object CubeLut {
    private val ws = Regex("\\s+")

    fun parse(f: File): LutData {
        var n = 0
        var data = FloatArray(0)
        var idx = 0
        f.forEachLine { raw ->
            val l = raw.trim()
            if (l.isEmpty() || l[0] == '#') return@forEachLine
            val c = l[0]
            if (c.isDigit() || c == '-' || c == '+' || c == '.') {
                if (data.isEmpty()) throw IllegalArgumentException("LUT_3D_SIZE missing")
                val p = l.split(ws)
                if (p.size < 3) return@forEachLine
                if (idx + 3 > data.size) throw IllegalArgumentException("too many entries")
                data[idx++] = p[0].toFloat(); data[idx++] = p[1].toFloat(); data[idx++] = p[2].toFloat()
            } else if (l.startsWith("LUT_3D_SIZE")) {
                n = l.split(ws)[1].toInt()
                if (n !in 2..65) throw IllegalArgumentException("unsupported LUT size $n")
                data = FloatArray(n * n * n * 3)
            } else if (l.startsWith("LUT_1D_SIZE")) {
                throw IllegalArgumentException("1D LUTs are not supported")
            }
        }
        if (n == 0 || idx != data.size) throw IllegalArgumentException("invalid .cube file")
        return LutData(n, data)
    }
}

/**
 * OpenGL pipeline: camera -> (log curve) -> encoder surface   (always the log image)
 *                         -> (log curve + LUT / 709 view) -> preview (monitoring only)
 * Everything GL happens on its own thread.
 */
class GlPipeline {
    /** 0 none, 1 S-Log3, 2 LogC3, 3 HLG */
    @Volatile var curve = 0
    /** preview only: 0 raw (shows the log image), 1 inverse curve (Rec.709 view), 2 3D LUT */
    @Volatile var viewMode = 0
    /** clockwise rotation (deg) that makes the sensor image upright on the current display */
    @Volatile var previewRot = 0
    @Volatile var tenBitActive = false

    private val thread = HandlerThread("gl").apply { start() }
    private val h = Handler(thread.looper)
    @Volatile private var released = false

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var prevSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var encSurf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var encoding = false
    private var encW = 0
    private var encH = 0
    private var encFirstTs = -1L
    private var wallBase: AtomicLong? = null

    private var prog = 0
    private var oesTex = 0
    private var lutTex = 0
    private var lutN = 2
    private var lutLoaded = false
    private var camSt: SurfaceTexture? = null
    private var camSurface: Surface? = null
    private var uSt = 0
    private var uRot = 0
    private var uCurve = 0
    private var uView = 0
    private var uLutScale = 0
    private var uLutOff = 0
    private val stm = FloatArray(16)
    private val rot = FloatArray(4)
    private var lutPending: LutData? = null

    fun setLut(l: LutData?) { synchronized(this) { lutPending = l } }

    // ------------------------------------------------------------------ start / stop

    /** Returns the Surface the camera must write to, or null on failure. */
    fun start(prev: SurfaceTexture, w: Int, hh: Int, wantTen: Boolean): Surface? {
        var res: Surface? = null
        val latch = CountDownLatch(1)
        h.post {
            try {
                var ok = wantTen && initEgl(prev, true)
                if (!ok) { teardownEgl(); ok = initEgl(prev, false) }
                if (ok) res = initGl(w, hh)
            } catch (e: Exception) {
                res = null
            }
            latch.countDown()
        }
        latch.await(4, TimeUnit.SECONDS)
        return res
    }

    fun release() {
        val latch = CountDownLatch(1)
        h.post {
            released = true
            try { camSt?.setOnFrameAvailableListener(null) } catch (e: Exception) {}
            try { camSurface?.release() } catch (e: Exception) {}
            try { camSt?.release() } catch (e: Exception) {}
            camSurface = null; camSt = null
            teardownEgl()
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        thread.quitSafely()
    }

    fun startEncoding(s: Surface, w: Int, hh: Int, wall: AtomicLong): Boolean {
        var ok = false
        val latch = CountDownLatch(1)
        h.post {
            try {
                val c = cfg
                if (c != null && dpy != EGL14.EGL_NO_DISPLAY) {
                    val sf = EGL14.eglCreateWindowSurface(dpy, c, s, intArrayOf(EGL14.EGL_NONE), 0)
                    if (sf != EGL14.EGL_NO_SURFACE) {
                        encSurf = sf; encW = w; encH = hh; encFirstTs = -1L; wallBase = wall
                        encoding = true; ok = true
                    }
                }
            } catch (e: Exception) { ok = false }
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
        return ok
    }

    fun stopEncoding() {
        val latch = CountDownLatch(1)
        h.post {
            encoding = false
            try {
                if (encSurf != EGL14.EGL_NO_SURFACE) {
                    EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
                    EGL14.eglDestroySurface(dpy, encSurf)
                }
            } catch (e: Exception) {}
            encSurf = EGL14.EGL_NO_SURFACE
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
    }

    // ------------------------------------------------------------------ EGL

    private fun chooseConfig(ten: Boolean, renderable: Int): EGLConfig? {
        val c = if (ten) 10 else 8
        val a = if (ten) 2 else 8
        val attrs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, renderable,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_RED_SIZE, c, EGL14.EGL_GREEN_SIZE, c, EGL14.EGL_BLUE_SIZE, c,
            EGL14.EGL_ALPHA_SIZE, a,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        if (!EGL14.eglChooseConfig(dpy, attrs, 0, cfgs, 0, 1, n, 0) || n[0] <= 0) return null
        val got = cfgs[0] ?: return null
        if (ten) {
            val r = IntArray(1)
            EGL14.eglGetConfigAttrib(dpy, got, EGL14.EGL_RED_SIZE, r, 0)
            if (r[0] != 10) return null
        }
        return got
    }

    private fun initEgl(prev: SurfaceTexture, ten: Boolean): Boolean {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (dpy == EGL14.EGL_NO_DISPLAY) return false
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) return false
        val c = chooseConfig(ten, 0x40) ?: chooseConfig(ten, EGL14.EGL_OPENGL_ES2_BIT) ?: return false
        cfg = c
        ctx = EGL14.eglCreateContext(dpy, c, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        if (ctx == EGL14.EGL_NO_CONTEXT) return false
        prevSurf = EGL14.eglCreateWindowSurface(dpy, c, prev, intArrayOf(EGL14.EGL_NONE), 0)
        if (prevSurf == EGL14.EGL_NO_SURFACE) return false
        if (!EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)) return false
        EGL14.eglSwapInterval(dpy, 0)
        tenBitActive = ten
        return true
    }

    private fun teardownEgl() {
        try {
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (encSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, encSurf)
                if (prevSurf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, prevSurf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
            }
        } catch (e: Exception) {}
        encSurf = EGL14.EGL_NO_SURFACE
        prevSurf = EGL14.EGL_NO_SURFACE
        ctx = EGL14.EGL_NO_CONTEXT
        encoding = false
        tenBitActive = false
    }

    // ------------------------------------------------------------------ GL

    private fun initGl(w: Int, hh: Int): Surface {
        prog = buildProgram(VERT, FRAG)
        GLES20.glUseProgram(prog)
        uSt = GLES20.glGetUniformLocation(prog, "uSt")
        uRot = GLES20.glGetUniformLocation(prog, "uRot")
        uCurve = GLES20.glGetUniformLocation(prog, "uCurve")
        uView = GLES20.glGetUniformLocation(prog, "uView")
        uLutScale = GLES20.glGetUniformLocation(prog, "uLutScale")
        uLutOff = GLES20.glGetUniformLocation(prog, "uLutOff")
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uLut"), 1)

        val verts = floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f)
        val fb = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(verts); fb.position(0)
        val vbo = IntArray(1)
        GLES20.glGenBuffers(1, vbo, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, verts.size * 4, fb, GLES20.GL_STATIC_DRAW)
        val aPos = GLES20.glGetAttribLocation(prog, "aPos")
        val aTex = GLES20.glGetAttribLocation(prog, "aTex")
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, 0)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, 8)

        val t = IntArray(2)
        GLES20.glGenTextures(2, t, 0)
        oesTex = t[0]; lutTex = t[1]
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        // identity placeholder so the sampler is always valid
        val id = FloatArray(2 * 2 * 2 * 3)
        var k = 0
        for (b in 0..1) for (g in 0..1) for (r in 0..1) { id[k++] = r.toFloat(); id[k++] = g.toFloat(); id[k++] = b.toFloat() }
        uploadLut(LutData(2, id))
        lutLoaded = false

        val st = SurfaceTexture(oesTex)
        st.setDefaultBufferSize(w, hh)
        st.setOnFrameAvailableListener({ onFrame() }, h)
        camSt = st
        val s = Surface(st)
        camSurface = s
        return s
    }

    private fun uploadLut(l: LutData) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES30.GL_TEXTURE_3D, lutTex)
        GLES20.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES20.GL_CLAMP_TO_EDGE)
        val fb = ByteBuffer.allocateDirect(l.rgb.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(l.rgb); fb.position(0)
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_RGB16F, l.n, l.n, l.n, 0,
            GLES20.GL_RGB, GLES20.GL_FLOAT, fb)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        lutN = l.n
        lutLoaded = true
    }

    /** Which way the camera's transform matrix already rotated the picture (clockwise degrees). */
    private fun theta(): Int =
        if (abs(stm[0]) > abs(stm[1])) (if (stm[0] > 0) 0 else 180)
        else (if (stm[1] < 0) 90 else 270)

    private fun draw(w: Int, hh: Int, delta: Int, view: Int) {
        GLES20.glViewport(0, 0, w, hh)
        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(uSt, 1, false, stm, 0)
        val a = Math.toRadians(delta.toDouble())
        val c = cos(a).toFloat()
        val s = sin(a).toFloat()
        rot[0] = c; rot[1] = s; rot[2] = -s; rot[3] = c
        GLES20.glUniformMatrix2fv(uRot, 1, false, rot, 0)
        GLES20.glUniform1i(uCurve, curve)
        GLES20.glUniform1i(uView, view)
        GLES20.glUniform1f(uLutScale, (lutN - 1f) / lutN)
        GLES20.glUniform1f(uLutOff, 0.5f / lutN)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun onFrame() {
        if (released || dpy == EGL14.EGL_NO_DISPLAY || prevSurf == EGL14.EGL_NO_SURFACE) return
        val st = camSt ?: return
        if (!EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)) return
        try { st.updateTexImage() } catch (e: Exception) { return }
        st.getTransformMatrix(stm)
        val ts = st.timestamp
        val pend = synchronized(this) { val p = lutPending; lutPending = null; p }
        if (pend != null) uploadLut(pend)
        val theta = theta()

        // ---- preview (monitoring) ----
        val wh = IntArray(1)
        val hh = IntArray(1)
        EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_WIDTH, wh, 0)
        EGL14.eglQuerySurface(dpy, prevSurf, EGL14.EGL_HEIGHT, hh, 0)
        if (wh[0] > 0 && hh[0] > 0) {
            val vm = viewMode
            val view = if (vm == 2 && !lutLoaded) 0 else vm
            draw(wh[0], hh[0], (previewRot - theta + 360) % 360, view)
            EGL14.eglSwapBuffers(dpy, prevSurf)
        }

        // ---- encoder: always the pure log image, raw sensor orientation ----
        if (encoding && encSurf != EGL14.EGL_NO_SURFACE) {
            if (EGL14.eglMakeCurrent(dpy, encSurf, encSurf, ctx)) {
                EGL14.eglSwapInterval(dpy, 0)
                draw(encW, encH, (360 - theta) % 360, 0)
                if (encFirstTs < 0) {
                    encFirstTs = ts
                    wallBase?.set(SystemClock.elapsedRealtimeNanos())
                }
                EGLExt.eglPresentationTimeANDROID(dpy, encSurf, ts - encFirstTs)
                EGL14.eglSwapBuffers(dpy, encSurf)
                EGL14.eglMakeCurrent(dpy, prevSurf, prevSurf, ctx)
            }
        }
    }

    private fun buildProgram(vs: String, fs: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vs)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v); GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("shader: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private companion object {
        const val VERT = """#version 300 es
in vec2 aPos;
in vec2 aTex;
uniform mat4 uSt;
uniform mat2 uRot;
out vec2 vTex;
void main() {
    vec2 p = uRot * (aTex - 0.5) + 0.5;
    vTex = (uSt * vec4(p, 0.0, 1.0)).xy;
    gl_Position = vec4(aPos, 0.0, 1.0);
}
"""
        const val FRAG = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
precision highp sampler3D;
uniform samplerExternalOES uTex;
uniform sampler3D uLut;
uniform int uCurve;
uniform int uView;
uniform float uLutScale;
uniform float uLutOff;
in vec2 vTex;
out vec4 oColor;

const mat3 TO2020 = mat3(0.6274, 0.0691, 0.0164, 0.3293, 0.9195, 0.0880, 0.0433, 0.0114, 0.8956);
const mat3 TO709 = mat3(1.6605, -0.1246, -0.0182, -0.5876, 1.1329, -0.1006, -0.0728, -0.0083, 1.1187);
const float HLG_GAIN = 0.2646;

vec3 toLin(vec3 c) {
    c = clamp(c, 0.0, 1.0);
    return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), vec3(greaterThan(c, vec3(0.04045))));
}
vec3 toSrgb(vec3 c) {
    c = clamp(c, 0.0, 1.0);
    return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, vec3(greaterThan(c, vec3(0.0031308))));
}
float slogE(float x) {
    x = max(x, 0.0);
    if (x >= 0.01125) return (420.0 + log2((x + 0.01) / 0.19) * 0.301029996 * 261.5) / 1023.0;
    return (x * (171.2102946929 - 95.0) / 0.01125 + 95.0) / 1023.0;
}
float slogD(float y) {
    if (y >= 171.2102946929 / 1023.0) return pow(10.0, (y * 1023.0 - 420.0) / 261.5) * 0.19 - 0.01;
    return (y * 1023.0 - 95.0) * 0.01125 / (171.2102946929 - 95.0);
}
float logcE(float x) {
    x = max(x, 0.0);
    if (x > 0.010591) return 0.24719 * log2(5.555556 * x + 0.052272) * 0.301029996 + 0.385537;
    return 5.367655 * x + 0.092809;
}
float logcD(float y) {
    if (y > 0.149658) return (pow(10.0, (y - 0.385537) / 0.24719) - 0.052272) / 5.555556;
    return (y - 0.092809) / 5.367655;
}
float hlgE(float e) {
    e = max(e, 0.0);
    if (e <= 1.0 / 12.0) return sqrt(3.0 * e);
    return 0.17883277 * log(12.0 * e - 0.28466892) + 0.55991073;
}
float hlgD(float y) {
    if (y <= 0.5) return y * y / 3.0;
    return (exp((y - 0.55991073) / 0.17883277) + 0.28466892) / 12.0;
}
vec3 enc(vec3 l) {
    if (uCurve == 1) return vec3(slogE(l.r), slogE(l.g), slogE(l.b));
    if (uCurve == 2) return vec3(logcE(l.r), logcE(l.g), logcE(l.b));
    vec3 w = TO2020 * l * HLG_GAIN;
    return vec3(hlgE(w.r), hlgE(w.g), hlgE(w.b));
}
vec3 dec(vec3 y) {
    if (uCurve == 1) return vec3(slogD(y.r), slogD(y.g), slogD(y.b));
    if (uCurve == 2) return vec3(logcD(y.r), logcD(y.g), logcD(y.b));
    vec3 w = vec3(hlgD(y.r), hlgD(y.g), hlgD(y.b)) / HLG_GAIN;
    return TO709 * w;
}
void main() {
    vec3 c = texture(uTex, vTex).rgb;
    if (uCurve != 0) c = clamp(enc(toLin(c)), 0.0, 1.0);
    if (uView == 1 && uCurve != 0) {
        c = toSrgb(dec(c));
    } else if (uView == 2) {
        c = texture(uLut, clamp(c, 0.0, 1.0) * uLutScale + uLutOff).rgb;
    }
    oColor = vec4(c, 1.0);
}
"""
    }
}
