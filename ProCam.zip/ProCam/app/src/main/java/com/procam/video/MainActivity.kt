package com.procam.video

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.display.DisplayManager
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

@SuppressLint("NewApi", "MissingPermission", "ClickableViewAccessibility")
@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private enum class P { ISO, SHUTTER, FOCUS, WB, EV, ZOOM }

    companion object {
        private val ACCENT = 0xFFFFC400.toInt()
        private val GREY = 0xFF9A9A9A.toInt()
        private val RATIOS = listOf(
            "16:9" to 16f / 9f, "4:3" to 4f / 3f, "3:2" to 1.5f,
            "1:1" to 1f, "2:1" to 2f, "21:9" to 21f / 9f
        )
        private val ISO_STOPS = listOf(
            50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250,
            1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 16000, 20000,
            25600, 32000, 40000, 51200
        )
        private val SHUT_DENOMS = listOf(
            8000, 6000, 4000, 3000, 2000, 1500, 1000, 750, 500, 350, 250, 180, 125,
            100, 90, 60, 50, 48, 30, 25, 24
        )
        private val BITRATES = listOf(0, 10, 20, 40, 60, 80, 100, 150)
    }

    // ---------------- threads ----------------
    private val bgThread = HandlerThread("cam").apply { start() }
    private val bg = Handler(bgThread.looper)
    private val ui = Handler(Looper.getMainLooper())

    // ---------------- views ----------------
    private lateinit var root: FrameLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var textureView: TextureView
    private lateinit var grid: GridOverlay
    private lateinit var focusRing: View
    private lateinit var topRow: LinearLayout
    private lateinit var optScroll: HorizontalScrollView
    private lateinit var optRow: LinearLayout
    private var optOwner: View? = null
    private lateinit var chipRes: TextView
    private lateinit var chipFps: TextView
    private lateinit var chipRatio: TextView
    private lateinit var chipCodec: TextView
    private lateinit var chipBit: TextView
    private lateinit var chipGrid: TextView
    private lateinit var chipStab: TextView
    private lateinit var dial: DialView
    private lateinit var autoBtn: TextView
    private val tabName = mutableMapOf<P, TextView>()
    private val tabValue = mutableMapOf<P, TextView>()
    private lateinit var lensCol: LinearLayout
    private lateinit var timerText: TextView
    private lateinit var recBtn: RecordButton

    // ---------------- camera state ----------------
    private lateinit var cm: CameraManager
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var recorderSurface: Surface? = null
    private var reqBuilder: CaptureRequest.Builder? = null
    private var active = false
    private var ready = false
    private var opening = false
    private var openGen = 0
    private var askedPerms = false

    private var backIds = listOf<String>()
    private var lensLabels = mapOf<String, String>()
    private var camId = ""
    private lateinit var chars: CameraCharacteristics
    private var sensorOri = 90
    private var activeArray = Rect(0, 0, 4000, 3000)
    private var isoRange: Range<Int> = Range(100, 800)
    private var expRange: Range<Long> = Range(1_000_000L, 33_000_000L)
    private var minFocusDist = 0f
    private var hasManualSensor = false
    private var awbAvail = IntArray(0)
    private var afAvail = IntArray(0)
    private var evMin = 0
    private var evMax = 0
    private var evStep = 0.33f
    private var fpsRanges: Array<Range<Int>> = arrayOf(Range(30, 30))
    private var maxZoom = 1f
    private var hasOis = false
    private var hasEis = false
    private var allSizes = listOf<Size>()

    // ---------------- video settings ----------------
    private var ratioKey = "16:9"
    private var ratioList = listOf<String>()
    private var sizes = listOf<Size>()
    private var size = Size(1920, 1080)
    private var previewSize = Size(1280, 720)
    private var fps = 30
    private var fpsOptions = listOf(30)
    private var hevc = false
    private var hevcAvail = false
    private var bitrateMbps = 0
    private var stab = false

    // ---------------- manual control state ----------------
    private var manualExp = false
    private var manualFocus = false
    private var isoList = listOf(100)
    private var shutList = listOf(16_666_666L)
    private var isoIdx = 0
    private var shutIdx = 0
    private var focusIdx = 0
    private var wbOpts = listOf("AUTO" to CameraMetadata.CONTROL_AWB_MODE_AUTO)
    private var wbIdx = 0
    private var evIdx = 0
    private var zoomIdx = 0
    private var selected = P.ISO
    private var afRegion: MeteringRectangle? = null

    private var lastIso = 400
    private var lastExp = 16_666_666L
    private var lastFocus = 0f
    private var frameCount = 0

    // ---------------- recording ----------------
    private var recorder: MediaRecorder? = null
    private var recording = false
    private var recStart = 0L
    private var pendingUri: Uri? = null
    private var pendingPfd: ParcelFileDescriptor? = null
    private var pendingFile: File? = null

    // =====================================================================
    // Lifecycle
    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        hevcAvail = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals("video/hevc", true) }
            }
        } catch (e: Exception) { false }
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        active = true
        hideSystemUi()
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, ui)
        if (!hasPerms()) {
            if (!askedPerms) {
                askedPerms = true
                val p = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT <= 28) p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                requestPermissions(p.toTypedArray(), 1)
            }
            return
        }
        if (!ready) initCameras()
        if (ready && textureView.isAvailable) openCamera()
    }

    override fun onPause() {
        active = false
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        bgThread.quitSafely()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        layoutPreview()
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { textureView.post { applyTransform() } }
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fmt(f: String, vararg a: Any) = String.format(Locale.US, f, *a)

    // =====================================================================
    // UI construction
    // =====================================================================
    private fun chip(text: String, sel: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTypeface(Typeface.DEFAULT_BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(6), dp(12), dp(6))
        styleChip(this, sel)
    }

    private fun styleChip(t: TextView, sel: Boolean) {
        t.background = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (sel) ACCENT else 0x66000000)
            if (!sel) setStroke(dp(1), 0x44FFFFFF)
        }
        t.setTextColor(if (sel) Color.BLACK else Color.WHITE)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)
        val panelW = dp(104)

        // ---- preview ----
        previewBox = FrameLayout(this)
        textureView = TextureView(this)
        previewBox.addView(textureView, FrameLayout.LayoutParams(-1, -1))
        grid = GridOverlay(this)
        previewBox.addView(grid, FrameLayout.LayoutParams(-1, -1))
        focusRing = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setStroke(dp(2), ACCENT); setColor(Color.TRANSPARENT)
            }
            visibility = View.GONE
        }
        previewBox.addView(focusRing, FrameLayout.LayoutParams(dp(64), dp(64)))
        root.addView(previewBox, FrameLayout.LayoutParams(dp(100), dp(100)))
        previewBox.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                optScroll.visibility = View.GONE
                tapFocus(e.x, e.y)
            }
            true
        }
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                if (active && ready) openCamera()
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        root.addOnLayoutChangeListener { _, l, t, r, bt, ol, ot, orr, ob ->
            if (r - l != orr - ol || bt - t != ob - ot) layoutPreview()
        }

        // ---- top settings bar ----
        topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(8), dp(10), dp(4))
        }
        val topScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(topRow)
        }
        root.addView(topScroll, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.TOP; rightMargin = panelW
        })
        chipRes = topChip {
            showOptions(chipRes, sizes.map { sizeLabel(it) }, sizes.indexOf(size)) { i ->
                size = sizes[i]; onVideoConfigChanged()
            }
        }
        chipFps = topChip {
            showOptions(chipFps, fpsOptions.map { "$it fps" }, fpsOptions.indexOf(fps)) { i ->
                fps = fpsOptions[i]; onFpsChanged()
            }
        }
        chipRatio = topChip {
            showOptions(chipRatio, ratioList, ratioList.indexOf(ratioKey)) { i ->
                applyRatio(ratioList[i]); onVideoConfigChanged()
            }
        }
        chipCodec = topChip {
            if (!hevcAvail) { toast("HEVC encoder not available on this device"); return@topChip }
            showOptions(chipCodec, listOf("H.264", "HEVC"), if (hevc) 1 else 0) { i ->
                hevc = i == 1; refreshTopChips()
            }
        }
        chipBit = topChip {
            showOptions(chipBit, BITRATES.map { if (it == 0) "AUTO" else "$it Mbps" }, BITRATES.indexOf(bitrateMbps)) { i ->
                bitrateMbps = BITRATES[i]; refreshTopChips()
            }
        }
        chipGrid = topChip { grid.on = !grid.on; refreshTopChips() }
        chipStab = topChip {
            if (!hasOis && !hasEis) toast("No stabilization available on this camera")
            else { stab = !stab; refreshTopChips(); pushRequest() }
        }

        optRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        optScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            visibility = View.GONE
            addView(optRow)
        }
        root.addView(optScroll, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.TOP; topMargin = dp(46); rightMargin = panelW
        })

        // ---- bottom manual panel ----
        dial = DialView(this).apply { onChange = { onDial(it) } }
        val tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), dp(6))
        }
        autoBtn = chip("AUTO").apply {
            textSize = 10f
            setPadding(0, 0, 0, 0)
            setOnClickListener { onAuto() }
        }
        tabsRow.addView(autoBtn, LinearLayout.LayoutParams(dp(50), dp(32)).apply { rightMargin = dp(6) })
        for (p in P.values()) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(2), 0, dp(2))
                setOnClickListener { selected = p; refreshDial(); refreshTabs() }
            }
            val n = TextView(this).apply { textSize = 10f; setTextColor(GREY); text = p.name }
            val v = TextView(this).apply {
                textSize = 15f; setTextColor(Color.WHITE); setTypeface(Typeface.DEFAULT_BOLD)
            }
            col.addView(n); col.addView(v)
            tabName[p] = n; tabValue[p] = v
            tabsRow.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x99000000.toInt())
            addView(dial, LinearLayout.LayoutParams(-1, dp(56)))
            addView(tabsRow, LinearLayout.LayoutParams(-1, -2))
        }
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.BOTTOM; rightMargin = panelW
        })

        // ---- right panel ----
        val rp = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF0B0B0B.toInt())
            setPadding(0, dp(10), 0, dp(10))
        }
        lensCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        rp.addView(lensCol, LinearLayout.LayoutParams(-1, -2))
        rp.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        timerText = TextView(this).apply {
            text = "00:00"; textSize = 14f; setTextColor(Color.WHITE); setTypeface(Typeface.DEFAULT_BOLD)
        }
        rp.addView(timerText, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(8) })
        recBtn = RecordButton(this).apply { setOnClickListener { toggleRecord() } }
        rp.addView(recBtn, LinearLayout.LayoutParams(dp(76), dp(76)))
        rp.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(rp, FrameLayout.LayoutParams(panelW, -1).apply { gravity = Gravity.END })
    }

    private fun topChip(onClick: () -> Unit): TextView {
        val c = chip("")
        c.setOnClickListener { onClick() }
        topRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        return c
    }

    private fun showOptions(anchor: View, items: List<String>, cur: Int, pick: (Int) -> Unit) {
        if (recording) { toast("Stop recording to change this setting"); return }
        if (optOwner === anchor && optScroll.visibility == View.VISIBLE) {
            optScroll.visibility = View.GONE; return
        }
        optOwner = anchor
        optRow.removeAllViews()
        items.forEachIndexed { i, s ->
            val c = chip(s, i == cur)
            c.setOnClickListener { optScroll.visibility = View.GONE; pick(i) }
            optRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        optScroll.visibility = View.VISIBLE
    }

    private fun buildLensButtons() {
        lensCol.removeAllViews()
        if (backIds.size < 2) return
        for (id in backIds) {
            val c = chip(lensLabels[id] ?: id, id == camId)
            c.setOnClickListener { switchCamera(id) }
            lensCol.addView(c, LinearLayout.LayoutParams(dp(60), -2).apply { bottomMargin = dp(6) })
        }
    }

    private fun layoutPreview() {
        val aw = root.width - dp(104)
        val ah = root.height
        if (aw <= 0 || ah <= 0) return
        val r = size.width.toFloat() / size.height
        var w = aw.toFloat()
        var h = w / r
        if (h > ah) { h = ah.toFloat(); w = h * r }
        val lp = FrameLayout.LayoutParams(w.roundToInt(), h.roundToInt())
        lp.leftMargin = ((aw - w) / 2).roundToInt()
        lp.topMargin = ((ah - h) / 2).roundToInt()
        previewBox.layoutParams = lp
        textureView.post { applyTransform() }
    }

    private fun applyTransform() {
        val w = textureView.width.toFloat()
        val h = textureView.height.toFloat()
        if (w == 0f) return
        val m = Matrix()
        if (rotHint() == 180) m.postRotate(180f, w / 2, h / 2)
        textureView.setTransform(m)
    }

    private fun tapFocus(x: Float, y: Float) {
        val w = previewBox.width.toFloat()
        val h = previewBox.height.toFloat()
        if (w == 0f || manualFocus || !afAvail.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) return
        var nx = (x / w).coerceIn(0f, 1f)
        var ny = (y / h).coerceIn(0f, 1f)
        if (rotHint() == 180) { nx = 1 - nx; ny = 1 - ny }
        val aw = activeArray.width()
        val ah = activeArray.height()
        val half = (min(aw, ah) * 0.08f).toInt()
        val cx = activeArray.left + (nx * aw).toInt()
        val cy = activeArray.top + (ny * ah).toInt()
        val rx = (cx - half).coerceIn(activeArray.left, activeArray.right - 2 * half - 1)
        val ry = (cy - half).coerceIn(activeArray.top, activeArray.bottom - 2 * half - 1)
        afRegion = MeteringRectangle(rx, ry, half * 2, half * 2, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        pushRequest()

        val lp = focusRing.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = (x - dp(32)).toInt(); lp.topMargin = (y - dp(32)).toInt()
        focusRing.layoutParams = lp
        focusRing.animate().cancel()
        focusRing.alpha = 1f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().alpha(0f).setStartDelay(700).setDuration(300)
            .withEndAction { focusRing.visibility = View.GONE }.start()
    }

    // =====================================================================
    // UI refresh helpers
    // =====================================================================
    private fun sizeLabel(s: Size): String {
        val r = s.width.toFloat() / s.height
        if (abs(r - 16f / 9f) < 0.02f) {
            return when {
                s.height >= 4320 -> "8K"
                s.height >= 2160 -> "4K"
                s.height >= 1440 -> "1440p"
                else -> "${s.height}p"
            }
        }
        return "${s.width}×${s.height}"
    }

    private fun shutLabel(ns: Long) = "1/" + (1e9 / ns).roundToInt()

    private fun focusLabel(i: Int): String {
        if (minFocusDist <= 0f) return "FIX"
        if (i == 0) return "∞"
        val m = 1f / (minFocusDist * i / 100f)
        return if (m >= 10f) fmt("%.0fm", m) else fmt("%.1fm", m)
    }

    private fun refreshTopChips() {
        chipRes.text = sizeLabel(size)
        chipFps.text = "$fps FPS"
        chipRatio.text = ratioKey
        chipCodec.text = if (hevc) "HEVC" else "H.264"
        chipBit.text = if (bitrateMbps == 0) "AUTO" else "${bitrateMbps}M"
        chipGrid.text = "GRID"; styleChip(chipGrid, grid.on)
        chipStab.text = "STAB"; styleChip(chipStab, stab)
        for (c in listOf(chipRes, chipFps, chipRatio, chipCodec, chipBit)) styleChip(c, false)
    }

    private fun isAuto(p: P) = when (p) {
        P.ISO, P.SHUTTER -> !manualExp
        P.FOCUS -> !manualFocus
        P.WB -> wbIdx == 0
        P.EV -> evIdx == -evMin
        P.ZOOM -> zoomIdx == 0
    }

    private fun refreshTabs() {
        tabValue[P.ISO]?.text = isoList.getOrNull(isoIdx)?.toString() ?: "-"
        tabValue[P.SHUTTER]?.text = shutList.getOrNull(shutIdx)?.let { shutLabel(it) } ?: "-"
        tabValue[P.FOCUS]?.text = focusLabel(focusIdx)
        tabValue[P.WB]?.text = wbOpts.getOrNull(wbIdx)?.first ?: "AUTO"
        tabValue[P.EV]?.text = fmt("%+.1f", (evMin + evIdx) * evStep)
        tabValue[P.ZOOM]?.text = fmt("%.1fx", 1f + zoomIdx * 0.1f)
        for (p in P.values()) {
            val sel = p == selected
            tabValue[p]?.setTextColor(if (sel) ACCENT else Color.WHITE)
            tabName[p]?.setTextColor(if (sel) ACCENT else GREY)
            val tag = (p == P.ISO || p == P.SHUTTER || p == P.FOCUS || p == P.WB) && isAuto(p)
            tabName[p]?.text = if (tag) "${p.name} A" else p.name
        }
        styleChip(autoBtn, isAuto(selected))
        dial.dimmed = selected == P.EV && manualExp
    }

    private fun refreshDial() {
        when (selected) {
            P.ISO -> dial.setup(isoList.map { it.toString() }, isoIdx, 3, 16f)
            P.SHUTTER -> dial.setup(shutList.map { shutLabel(it) }, shutIdx, 3, 20f)
            P.FOCUS -> dial.setup((0..100).map { focusLabel(it) }, focusIdx, 10, 8f)
            P.WB -> dial.setup(wbOpts.map { it.first }, wbIdx, 1, 64f)
            P.EV -> dial.setup(
                (evMin..evMax).map { fmt("%+.1f", it * evStep) }, evIdx,
                max(1, (1f / evStep).roundToInt()), 12f
            )
            P.ZOOM -> dial.setup((0..zoomSteps()).map { fmt("%.1fx", 1f + it * 0.1f) }, zoomIdx, 10, 8f)
        }
        dial.dimmed = selected == P.EV && manualExp
    }

    // =====================================================================
    // Dial / auto-button handling
    // =====================================================================
    private fun onDial(i: Int) {
        when (selected) {
            P.ISO -> if (needManualSensor()) { isoIdx = i; manualExp = true } else { refreshDial(); return }
            P.SHUTTER -> if (needManualSensor()) { shutIdx = i; manualExp = true } else { refreshDial(); return }
            P.FOCUS -> if (minFocusDist > 0f && hasManualSensor) { focusIdx = i; manualFocus = true }
                       else { toast("Manual focus not supported by this camera"); refreshDial(); return }
            P.WB -> wbIdx = i
            P.EV -> evIdx = i
            P.ZOOM -> zoomIdx = i
        }
        refreshTabs()
        pushRequest()
    }

    private fun needManualSensor(): Boolean {
        if (!hasManualSensor) toast("Manual exposure not supported by this camera")
        return hasManualSensor
    }

    private fun onAuto() {
        when (selected) {
            P.ISO, P.SHUTTER -> manualExp = false
            P.FOCUS -> manualFocus = false
            P.WB -> wbIdx = 0
            P.EV -> evIdx = (-evMin).coerceIn(0, max(0, evMax - evMin))
            P.ZOOM -> zoomIdx = 0
        }
        refreshDial(); refreshTabs(); pushRequest()
    }

    /** Called ~5x/s from the capture callback: follow the camera's metering while in auto. */
    private fun onMetered() {
        if (!manualExp) {
            isoIdx = nearestIso(lastIso); shutIdx = nearestShut(lastExp)
            if (selected == P.ISO) dial.setIndexSilently(isoIdx)
            if (selected == P.SHUTTER) dial.setIndexSilently(shutIdx)
        }
        if (!manualFocus && minFocusDist > 0f) {
            focusIdx = (lastFocus / minFocusDist * 100f).roundToInt().coerceIn(0, 100)
            if (selected == P.FOCUS) dial.setIndexSilently(focusIdx)
        }
        refreshTabs()
    }

    private fun nearestIso(v: Int) =
        isoList.indices.minByOrNull { abs(ln(isoList[it].toDouble() / v.coerceAtLeast(1))) } ?: 0

    private fun nearestShut(ns: Long) =
        shutList.indices.minByOrNull { abs(ln(shutList[it].toDouble() / ns.coerceAtLeast(1L))) } ?: 0

    private fun zoomSteps() = ((maxZoom - 1f) * 10).toInt().coerceAtLeast(0)

    // =====================================================================
    // Camera discovery / configuration
    // =====================================================================
    private fun initCameras() {
        try {
            val found = ArrayList<Pair<String, Float>>()
            for (id in cm.cameraIdList) {
                try {
                    val c = cm.getCameraCharacteristics(id)
                    if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
                    val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: continue
                    if (map.getOutputSizes(MediaRecorder::class.java).isNullOrEmpty()) continue
                    val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: continue
                    if (!caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
                    val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
                    val ss = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                    val ratio = if (ss != null && f > 0f) {
                        val diag = sqrt(ss.width * ss.width + ss.height * ss.height)
                        (f * 43.27f / diag) / 24f
                    } else 1f
                    found.add(id to ratio)
                } catch (e: Exception) { /* skip broken camera */ }
            }
            if (found.isEmpty()) { toast("No usable back camera found"); return }
            found.sortBy { it.second }
            backIds = found.map { it.first }
            lensLabels = found.associate { it.first to lensLabel(it.second) }
            val def = found.minByOrNull { abs(it.second - 1f) }!!.first
            loadCamera(def)
            buildLensButtons(); refreshTopChips(); refreshTabs(); refreshDial()
            ready = true
            layoutPreview()
        } catch (e: Exception) {
            toast("Camera init failed: ${e.message}")
        }
    }

    private fun lensLabel(r: Float): String {
        val x = (max(r, 0.5f) * 2).roundToInt() / 2f
        return if (x == x.toInt().toFloat()) "${x.toInt()}x" else "${x}x"
    }

    private fun loadCamera(id: String) {
        camId = id
        val c = cm.getCameraCharacteristics(id)
        chars = c
        sensorOri = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        activeArray = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)
        isoRange = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 800)
        expRange = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 33_000_000L)
        minFocusDist = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        hasManualSensor = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
        awbAvail = c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES) ?: intArrayOf()
        afAvail = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: intArrayOf()
        val evr = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        evMin = evr?.lower ?: 0
        evMax = evr?.upper ?: 0
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.33f
        if (evStep <= 0f) evStep = 0.33f
        fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: arrayOf(Range(30, 30))
        maxZoom = min(c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f, 10f)
        hasOis = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            ?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        hasEis = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            ?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        allSizes = map.getOutputSizes(MediaRecorder::class.java)
            .filter { min(it.width, it.height) >= 480 && it.width >= it.height }

        // reset per-camera manual state
        manualFocus = false; afRegion = null; zoomIdx = 0; wbIdx = 0
        evIdx = (-evMin).coerceIn(0, max(0, evMax - evMin))

        ratioList = RATIOS.filter { (_, r) -> allSizes.any { abs(it.width.toFloat() / it.height - r) < 0.02f } }
            .map { it.first }
        if (ratioList.isEmpty()) ratioList = listOf("16:9")
        if (ratioKey !in ratioList) ratioKey = ratioList.first()
        applyRatio(ratioKey)
        rebuildLists()
    }

    private fun applyRatio(key: String) {
        ratioKey = key
        val r = RATIOS.first { it.first == key }.second
        var list = allSizes.filter { abs(it.width.toFloat() / it.height - r) < 0.02f }
        if (list.isEmpty()) list = allSizes
        sizes = list.sortedByDescending { it.width.toLong() * it.height }
        val h = size.height
        size = sizes.minByOrNull { abs(it.height - h) } ?: sizes.first()
        refreshFpsOptions()
        pickPreviewSize()
    }

    private fun refreshFpsOptions() {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val minDur = try { map.getOutputMinFrameDuration(MediaRecorder::class.java, size) } catch (e: Exception) { 0L }
        val maxByRes = if (minDur > 0) (1e9 / minDur + 0.5).toInt() else 60
        fpsOptions = listOf(24, 25, 30, 48, 50, 60).filter { f ->
            f <= maxByRes && fpsRanges.any { it.lower <= f && f <= it.upper }
        }
        if (fpsOptions.isEmpty()) fpsOptions = listOf(30)
        if (fps !in fpsOptions) fps = fpsOptions.minByOrNull { abs(it - fps) }!!
    }

    private fun pickPreviewSize() {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val r = size.width.toFloat() / size.height
        previewSize = map.getOutputSizes(SurfaceTexture::class.java)
            .filter { abs(it.width.toFloat() / it.height - r) < 0.02f && it.width <= 1920 }
            .maxByOrNull { it.width.toLong() * it.height } ?: size
    }

    private fun rebuildLists() {
        val oldNs = shutList.getOrNull(shutIdx) ?: lastExp
        val oldIso = isoList.getOrNull(isoIdx) ?: lastIso
        isoList = ISO_STOPS.filter { it >= isoRange.lower && it <= isoRange.upper }
        if (isoList.isEmpty()) isoList = listOf(isoRange.lower)
        val frameNs = (1e9 / fps).toLong()
        shutList = SHUT_DENOMS.map { (1e9 / it).toLong() }
            .filter { it >= expRange.lower && it <= expRange.upper && it <= frameNs + 1000 }
        if (shutList.isEmpty()) shutList = listOf(expRange.lower.coerceAtMost(frameNs))
        isoIdx = nearestIso(oldIso)
        shutIdx = nearestShut(oldNs)

        val wb = ArrayList<Pair<String, Int>>()
        wb.add("AUTO" to CameraMetadata.CONTROL_AWB_MODE_AUTO)
        listOf(
            "2850K" to CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
            "4000K" to CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT,
            "5500K" to CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT,
            "6500K" to CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
            "7500K" to CameraMetadata.CONTROL_AWB_MODE_SHADE
        ).forEach { if (awbAvail.contains(it.second)) wb.add(it) }
        wbOpts = wb
        if (wbIdx >= wb.size) wbIdx = 0
        zoomIdx = zoomIdx.coerceIn(0, zoomSteps())
    }

    private fun onVideoConfigChanged() {
        refreshFpsOptions(); pickPreviewSize(); rebuildLists()
        layoutPreview(); refreshTopChips(); refreshTabs(); refreshDial()
        startPreview()
    }

    private fun onFpsChanged() {
        rebuildLists(); refreshTopChips(); refreshTabs(); refreshDial(); pushRequest()
    }

    private fun switchCamera(id: String) {
        if (recording) { toast("Stop recording to switch lens"); return }
        if (id == camId) return
        closeCamera()
        loadCamera(id)
        buildLensButtons(); refreshTopChips(); refreshTabs(); refreshDial(); layoutPreview()
        openCamera()
    }

    // =====================================================================
    // Camera2 plumbing
    // =====================================================================
    private fun openCamera() {
        if (!hasPerms() || !textureView.isAvailable || opening || device != null) return
        opening = true
        val token = ++openGen
        try {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    if (token == openGen) opening = false
                    if (!active || token != openGen) { c.close(); return }
                    device = c
                    startPreview()
                }
                override fun onDisconnected(c: CameraDevice) {
                    if (token == openGen) { opening = false; device = null }
                    c.close()
                }
                override fun onError(c: CameraDevice, e: Int) {
                    if (token == openGen) { opening = false; device = null }
                    c.close()
                    toast("Camera error $e")
                }
            }, bg)
        } catch (e: Exception) {
            opening = false
            toast("Cannot open camera: ${e.message}")
        }
    }

    private fun closeCamera() {
        openGen++
        opening = false
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        previewSurface?.release()
        previewSurface = null
        reqBuilder = null
    }

    private fun startPreview() {
        val dev = device ?: return
        val tex = textureView.surfaceTexture ?: return
        try {
            try { session?.close() } catch (e: Exception) {}
            session = null
            tex.setDefaultBufferSize(previewSize.width, previewSize.height)
            previewSurface?.release()
            val ps = Surface(tex)
            previewSurface = ps
            recorderSurface = null
            dev.createCaptureSession(listOf(ps), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device == null) return
                    session = s
                    try {
                        val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        b.addTarget(ps)
                        applyControls(b)
                        reqBuilder = b
                        s.setRepeatingRequest(b.build(), captureCb, bg)
                    } catch (e: Exception) { toast("Preview error: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { toast("Preview configuration failed") }
            }, bg)
        } catch (e: Exception) {
            toast("Preview error: ${e.message}")
        }
    }

    private val captureCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            res.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
            res.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastExp = it }
            res.get(CaptureResult.LENS_FOCUS_DISTANCE)?.let { lastFocus = it }
            if (++frameCount % 6 == 0) ui.post { onMetered() }
        }
    }

    private fun pickFpsRange(f: Int): Range<Int> =
        fpsRanges.firstOrNull { it.lower == f && it.upper == f }
            ?: fpsRanges.filter { it.lower <= f && f <= it.upper }
                .minByOrNull { abs(it.upper - f) * 2 + abs(it.lower - f) }
            ?: Range(f, f)

    private fun cropRegion(): Rect {
        val z = 1f + zoomIdx * 0.1f
        val w = (activeArray.width() / z).toInt()
        val h = (activeArray.height() / z).toInt()
        val l = activeArray.left + (activeArray.width() - w) / 2
        val t = activeArray.top + (activeArray.height() - h) / 2
        return Rect(l, t, l + w, t + h)
    }

    private fun applyControls(b: CaptureRequest.Builder) {
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pickFpsRange(fps))

        if (manualExp && hasManualSensor) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoList[isoIdx.coerceIn(0, isoList.lastIndex)])
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, shutList[shutIdx.coerceIn(0, shutList.lastIndex)])
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, (1e9 / fps).toLong())
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evMin + evIdx)
        }

        if (manualFocus && minFocusDist > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocusDist * focusIdx / 100f)
        } else if (afAvail.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
            afRegion?.let { b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(it)) }
        }

        wbOpts.getOrNull(wbIdx)?.let { b.set(CaptureRequest.CONTROL_AWB_MODE, it.second) }
        b.set(CaptureRequest.SCALER_CROP_REGION, cropRegion())

        if (hasEis) b.set(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            if (stab) CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON else CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
        )
        if (hasOis) b.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (stab) CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
    }

    private fun pushRequest() { bg.post { updateRepeating() } }

    private fun updateRepeating() {
        val s = session ?: return
        val b = reqBuilder ?: return
        try {
            applyControls(b)
            s.setRepeatingRequest(b.build(), captureCb, bg)
        } catch (e: Exception) { /* session closing */ }
    }

    // =====================================================================
    // Recording
    // =====================================================================
    private fun dispDeg() = when (windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> 90
        Surface.ROTATION_180 -> 180
        Surface.ROTATION_270 -> 270
        else -> 0
    }

    private fun rotHint() = (sensorOri - dispDeg() + 360) % 360

    private fun currentBitrate(): Int {
        if (bitrateMbps > 0) return bitrateMbps * 1_000_000
        val bpp = if (hevc) 0.14 else 0.2
        return (size.width.toLong() * size.height * fps * bpp).toLong()
            .coerceIn(8_000_000L, 200_000_000L).toInt()
    }

    private fun toggleRecord() {
        if (recording) stopRecording() else startRecording()
    }

    private fun openOutput(r: MediaRecorder) {
        val name = "PRO_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        pendingUri = null; pendingPfd = null; pendingFile = null
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("Cannot create file")
            pendingUri = uri
            pendingPfd = contentResolver.openFileDescriptor(uri, "w")
            r.setOutputFile(pendingPfd!!.fileDescriptor)
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "ProCam")
            dir.mkdirs()
            val f = File(dir, name)
            pendingFile = f
            r.setOutputFile(f.absolutePath)
        }
    }

    private fun finishOutput(ok: Boolean) {
        try { pendingPfd?.close() } catch (e: Exception) {}
        pendingPfd = null
        if (Build.VERSION.SDK_INT >= 29) {
            val uri = pendingUri
            if (uri != null) {
                if (ok) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(uri, v, null, null)
                } else contentResolver.delete(uri, null, null)
            }
        } else {
            val f = pendingFile
            if (f != null) {
                if (ok) MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), arrayOf("video/mp4"), null)
                else f.delete()
            }
        }
        pendingUri = null; pendingFile = null
        if (ok) toast("Saved to Movies/ProCam")
    }

    private fun setupRecorder(): Boolean {
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            val audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (audio) r.setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            openOutput(r)
            r.setVideoEncodingBitRate(currentBitrate())
            r.setVideoFrameRate(fps)
            r.setVideoSize(size.width, size.height)
            r.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) {
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioSamplingRate(48000)
                r.setAudioEncodingBitRate(192000)
            }
            r.setOrientationHint(rotHint())
            r.prepare()
            recorder = r
            true
        } catch (e: Exception) {
            toast("Recorder error: ${e.message}")
            releaseRecorder(false)
            false
        }
    }

    private fun releaseRecorder(ok: Boolean) {
        try { recorder?.reset() } catch (e: Exception) {}
        try { recorder?.release() } catch (e: Exception) {}
        recorder = null
        recorderSurface = null
        finishOutput(ok)
    }

    private fun startRecording() {
        val dev = device ?: return
        val ps = previewSurface ?: return
        if (!setupRecorder()) return
        val rs = recorder!!.surface
        recorderSurface = rs
        try { session?.close() } catch (e: Exception) {}
        session = null
        try {
            dev.createCaptureSession(listOf(ps, rs), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        b.addTarget(ps); b.addTarget(rs)
                        applyControls(b)
                        reqBuilder = b
                        s.setRepeatingRequest(b.build(), captureCb, bg)
                        recorder?.start()
                        recording = true
                        recStart = SystemClock.elapsedRealtime()
                        runOnUiThread { onRecordingChanged() }
                    } catch (e: Exception) {
                        toast("Cannot start recording: ${e.message}")
                        runOnUiThread { releaseRecorder(false); startPreview() }
                    }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    toast("Camera can't record this resolution / fps combination")
                    runOnUiThread { releaseRecorder(false); startPreview() }
                }
            }, bg)
        } catch (e: Exception) {
            toast("Cannot start recording: ${e.message}")
            releaseRecorder(false); startPreview()
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        var ok = true
        try { recorder?.stop() } catch (e: RuntimeException) { ok = false }
        releaseRecorder(ok)
        onRecordingChanged()
        startPreview()
    }

    private val timerTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            timerText.text = if (s >= 3600) fmt("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                             else fmt("%02d:%02d", s / 60, s % 60)
            ui.postDelayed(this, 250)
        }
    }

    private fun onRecordingChanged() {
        recBtn.recording = recording
        timerText.setTextColor(if (recording) 0xFFFF3B30.toInt() else Color.WHITE)
        val a = if (recording) 0.35f else 1f
        for (c in listOf(chipRes, chipFps, chipRatio, chipCodec, chipBit)) c.alpha = a
        lensCol.alpha = a
        if (recording) { optScroll.visibility = View.GONE; ui.post(timerTick) } else timerText.text = "00:00"
    }
}
