package com.procam.video

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.display.DisplayManager
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileDescriptor
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

@SuppressLint("NewApi", "MissingPermission", "ClickableViewAccessibility")
@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private enum class P { ISO, SHUTTER, FOCUS, WB, EV }

    private data class Lens(val id: String, val zoom: Float, val disp: Float)

    companion object {
        private const val CTRL_DP = 266
        private val ACCENT = 0xFFFFC400.toInt()
        private val GREY = 0xFF9A9A9A.toInt()
        private val RATIOS = listOf(
            "16:9" to 16f / 9f, "4:3" to 4f / 3f, "3:2" to 1.5f,
            "1:1" to 1f, "2:1" to 2f, "21:9" to 21f / 9f
        )
        private val ISO_STOPS = listOf(
            50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250,
            1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 16000, 20000,
            25600, 32000, 40000, 51200
        )
        private val SHUT_DENOMS = listOf(
            8000, 6000, 4000, 3000, 2000, 1500, 1000, 750, 500, 350, 250, 180, 125,
            100, 90, 60, 50, 48, 30, 25, 24
        )
        private val LOGS = listOf("OFF", "S-LOG3", "LOGC3", "HLG")
        private val BITRATES = listOf(0, 10, 20, 40, 60, 80, 100, 150)
    }

    // ---------------- threads ----------------
    private val bgThread = HandlerThread("cam").apply { start() }
    private val bg = Handler(bgThread.looper)
    private val ui = Handler(Looper.getMainLooper())

    // ---------------- views ----------------
    private lateinit var root: FrameLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var textureView: TextureView
    private lateinit var grid: GridOverlay
    private lateinit var focusRing: View
    private lateinit var topRow: LinearLayout
    private lateinit var topScroll: HorizontalScrollView
    private lateinit var settingsBox: LinearLayout
    private lateinit var flashView: FlashView
    private lateinit var formatLabel: TextView
    private lateinit var chevron: ChevronView
    private lateinit var lensRow: LinearLayout
    private lateinit var dialRow: LinearLayout
    private lateinit var expertPill: LinearLayout
    private lateinit var thumb: ImageView
    private lateinit var optScroll: HorizontalScrollView
    private lateinit var optRow: LinearLayout
    private var optOwner: View? = null
    private lateinit var chipRes: TextView
    private lateinit var chipFps: TextView
    private lateinit var chipRatio: TextView
    private lateinit var chipCodec: TextView
    private lateinit var chipBit: TextView
    private lateinit var chipGrid: TextView
    private lateinit var chipStab: TextView
    private lateinit var chipLog: TextView
    private lateinit var chipTen: TextView
    private lateinit var chipLut: TextView
    private lateinit var dial: DialView
    private lateinit var autoBtn: TextView
    private val tabName = mutableMapOf<P, TextView>()
    private val tabValue = mutableMapOf<P, TextView>()
    private val tabCol = mutableMapOf<P, LinearLayout>()
    private lateinit var timerText: TextView
    private lateinit var recBtn: RecordButton

    // ---------------- camera state ----------------
    private lateinit var cm: CameraManager
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var recorderSurface: Surface? = null
    private var reqBuilder: CaptureRequest.Builder? = null
    private var active = false
    private var ready = false
    private var opening = false
    private var openGen = 0
    private var askedPerms = false

    private var backIds = listOf<String>()
    private var lensLabels = mapOf<String, String>()
    private var camId = ""
    private lateinit var chars: CameraCharacteristics
    private var sensorOri = 90
    private var activeArray = Rect(0, 0, 4000, 3000)
    private var isoRange: Range<Int> = Range(100, 800)
    private var expRange: Range<Long> = Range(1_000_000L, 33_000_000L)
    private var minFocusDist = 0f
    private var hasManualSensor = false
    private var awbAvail = IntArray(0)
    private var afAvail = IntArray(0)
    private var evMin = 0
    private var evMax = 0
    private var evStep = 0.33f
    private var fpsRanges: Array<Range<Int>> = arrayOf(Range(30, 30))
    private var hasOis = false
    private var hasEis = false
    private var allSizes = listOf<Size>()

    // ---------------- video settings ----------------
    private var ratioKey = "16:9"
    private var ratioList = listOf<String>()
    private var sizes = listOf<Size>()
    private var size = Size(1920, 1080)
    private var previewSize = Size(1280, 720)
    private var fps = 30
    private var fpsOptions = listOf(30)
    private var hevc = false
    private var hevcAvail = false
    private var bitrateMbps = 0
    // 0 = off, 1 = OIS (lens shift), 2 = EIS (digital video stabilization); -1 = not chosen yet
    private var stabMode = -1

    // ---------------- log / 10-bit / LUT ----------------
    private var gl: GlPipeline? = null
    private var tenBit = false
    private var tenBitAvail = false
    private var logMode = 0           // index into LOGS
    private var lutSel = 0            // 0 off, 1 Rec.709 view, 2+ = imported LUT (lutFiles[i-2])
    private var lutFiles = listOf<File>()
    private var lutCache: LutData? = null
    private val lutDir by lazy { File(filesDir, "luts") }

    // ---------------- manual control state ----------------
    private var manualExp = false
    private var manualFocus = false
    private var isoList = listOf(100)
    private var shutList = listOf(16_666_666L)
    private var isoIdx = 0
    private var shutIdx = 0
    private var focusIdx = 0
    private var wbOpts = listOf("AUTO" to CameraMetadata.CONTROL_AWB_MODE_AUTO)
    private var wbIdx = 0
    private var evIdx = 0
    private var zoom = 1f
    private var zoomMin = 1f
    private var zoomMax = 1f
    private var useZoomRatio = false
    private var hasFlash = false
    private var torchOn = false
    private var pinched = false
    private var dialOpen = false
    private var baseDisp = mapOf<String, Float>()
    private var lensOpts = listOf<Lens>()
    private val badFps = HashSet<String>()
    private var devDeg = 0
    private var lastUri: Uri? = null
    private val orient by lazy {
        object : OrientationEventListener(this@MainActivity) {
            override fun onOrientationChanged(o: Int) {
                if (o == OrientationEventListener.ORIENTATION_UNKNOWN) return
                devDeg = ((o + 45) / 90 * 90) % 360
            }
        }
    }
    private var selected = P.ISO
    private var afRegion: MeteringRectangle? = null

    private var lastIso = 400
    private var lastExp = 16_666_666L
    private var lastFocus = 0f
    private var frameCount = 0

    // ---------------- recording ----------------
    private var rec: Recorder? = null
    private var recording = false
    private var recStart = 0L
    private var pendingUri: Uri? = null
    private var pendingPfd: ParcelFileDescriptor? = null
    private var pendingFile: File? = null

    // =====================================================================
    // Lifecycle
    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        hevcAvail = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals("video/hevc", true) }
            }
        } catch (e: Exception) { false }
        tenBitAvail = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals("video/hevc", true) } &&
                    ci.getCapabilitiesForType("video/hevc").profileLevels.any {
                        it.profile == MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10
                    }
            }
        } catch (e: Exception) { false }
        refreshLutFiles()
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        active = true
        hideSystemUi()
        if (orient.canDetectOrientation()) orient.enable()
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, ui)
        if (!hasPerms()) {
            if (!askedPerms) {
                askedPerms = true
                val p = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT <= 28) p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                requestPermissions(p.toTypedArray(), 1)
            }
            return
        }
        if (lastUri == null) loadLastThumb()
        if (!ready) initCameras()
        if (ready && textureView.isAvailable) openCamera()
    }

    override fun onPause() {
        active = false
        orient.disable()
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        bgThread.quitSafely()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        layoutPreview()
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { textureView.post { applyTransform() } }
    }

    private fun hasPerms() =
        checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fmt(f: String, vararg a: Any) = String.format(Locale.US, f, *a)

    // =====================================================================
    // UI construction
    // =====================================================================
    private fun chip(text: String, sel: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.04f
        gravity = Gravity.CENTER
        setPadding(dp(13), dp(7), dp(13), dp(7))
        styleChip(this, sel)
    }

    private fun styleChip(t: TextView, sel: Boolean) {
        t.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(if (sel) ACCENT else 0x73000000)
            if (!sel) setStroke(dp(1), 0x26FFFFFF)
        }
        t.setTextColor(if (sel) Color.BLACK else Color.WHITE)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)

        // ---- preview ----
        previewBox = FrameLayout(this)
        textureView = TextureView(this)
        previewBox.addView(textureView, FrameLayout.LayoutParams(-1, -1))
        grid = GridOverlay(this)
        previewBox.addView(grid, FrameLayout.LayoutParams(-1, -1))
        focusRing = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE; cornerRadius = dp(14).toFloat()
                setStroke(dp(2), ACCENT); setColor(Color.TRANSPARENT)
            }
            visibility = View.GONE
        }
        previewBox.addView(focusRing, FrameLayout.LayoutParams(dp(64), dp(64)))
        root.addView(previewBox, FrameLayout.LayoutParams(dp(100), dp(100)))
        val pinch = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { pinched = true; return true }
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoom(zoom * d.scaleFactor); return true }
        })
        previewBox.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) pinched = false
            pinch.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP && !pinched) {
                optScroll.visibility = View.GONE
                tapFocus(e.x, e.y)
            }
            true
        }
        textureView.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                if (active && ready) openCamera()
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                if (recording) stopRecording()
                closeCamera()
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        root.addOnLayoutChangeListener { _, l, t, r, bt, ol, ot, orr, ob ->
            if (r - l != orr - ol || bt - t != ob - ot) layoutPreview()
        }

        // ---- top settings bar ----
        topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(8), dp(10), dp(4))
        }
        topScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xB3000000.toInt(), 0x00000000)
            )
            addView(topRow)
        }
        settingsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        settingsBox.addView(topScroll, LinearLayout.LayoutParams(-1, -2))
        chipRes = topChip {
            showOptions(chipRes, sizes.map { sizeLabel(it) }, sizes.indexOf(size)) { i ->
                size = sizes[i]; onVideoConfigChanged()
            }
        }
        chipFps = topChip {
            showOptions(chipFps, fpsOptions.map { "$it fps" }, fpsOptions.indexOf(fps)) { i ->
                fps = fpsOptions[i]; onFpsChanged()
            }
        }
        chipLog = topChip {
            showOptions(chipLog, LOGS, logMode) { i -> setLog(i) }
        }
        chipTen = topChip {
            if (recording) { toast("Stop recording to change this setting"); return@topChip }
            if (!tenBitAvail) { toast("10-bit HEVC is not supported on this device"); return@topChip }
            tenBit = !tenBit
            if (tenBit) hevc = true
            refreshTopChips(); startPreview()
        }
        chipLut = topChip {
            val names = ArrayList<String>()
            names.add("OFF"); names.add("REC.709")
            lutFiles.forEach { names.add(it.nameWithoutExtension) }
            names.add("+ IMPORT")
            showOptions(chipLut, names, lutSel, true) { i ->
                if (i == names.size - 1) importLut() else selectLut(i)
            }
        }
        chipRatio = topChip {
            showOptions(chipRatio, ratioList, ratioList.indexOf(ratioKey)) { i ->
                applyRatio(ratioList[i]); onVideoConfigChanged()
            }
        }
        chipCodec = topChip {
            if (!hevcAvail) { toast("HEVC encoder not available on this device"); return@topChip }
            showOptions(chipCodec, listOf("H.264", "HEVC"), if (hevc) 1 else 0) { i ->
                hevc = i == 1
                if (!hevc && tenBit) { tenBit = false; startPreview() }
                refreshTopChips()
            }
        }
        chipBit = topChip {
            showOptions(chipBit, BITRATES.map { if (it == 0) "AUTO" else "$it Mbps" }, BITRATES.indexOf(bitrateMbps)) { i ->
                bitrateMbps = BITRATES[i]; refreshTopChips()
            }
        }
        chipGrid = topChip { grid.on = !grid.on; refreshTopChips() }
        chipStab = topChip {
            if (!hasOis && !hasEis) { toast("No stabilization available on this camera"); return@topChip }
            val modes = ArrayList<Int>(); val names = ArrayList<String>()
            modes.add(0); names.add("OFF")
            if (hasOis) { modes.add(1); names.add("OIS") }
            if (hasEis) { modes.add(2); names.add("EIS") }
            showOptions(chipStab, names, modes.indexOf(stabMode)) { i ->
                stabMode = modes[i]; refreshTopChips(); pushRequest()
            }
        }

        optRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        optScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            visibility = View.GONE
            addView(optRow)
        }
        settingsBox.addView(optScroll, LinearLayout.LayoutParams(-1, -2))
        root.addView(settingsBox, FrameLayout.LayoutParams(-1, -2).apply {
            gravity = Gravity.TOP; topMargin = dp(98)
        })

        // ---- top bar: flash | format | ... | timer | chevron ----
        flashView = FlashView(this).apply { setOnClickListener { toggleTorch() } }
        formatLabel = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.05f
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener { toggleSettings() }
        }
        timerText = TextView(this).apply {
            text = "00:00"; textSize = 13f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            fontFeatureSettings = "tnum"
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = timerBg(false)
            visibility = View.INVISIBLE
        }
        chevron = ChevronView(this).apply { setOnClickListener { toggleSettings() } }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(17), 0, dp(17), 0)
        }
        topBar.addView(flashView, LinearLayout.LayoutParams(dp(44), dp(44)))
        topBar.addView(formatLabel, LinearLayout.LayoutParams(-2, dp(44)).apply { leftMargin = dp(20) })
        topBar.addView(Space(this), LinearLayout.LayoutParams(0, 0, 1f))
        topBar.addView(timerText, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(12) })
        topBar.addView(chevron, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(52)).apply {
            gravity = Gravity.TOP; topMargin = dp(46)
        })

        // ---- lens / zoom pills (sit just above the controls) ----
        lensRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        root.addView(lensRow, FrameLayout.LayoutParams(-1, dp(44)).apply {
            gravity = Gravity.BOTTOM; bottomMargin = dp(CTRL_DP)
        })

        // ---- manual parameter row: EV ISO S WB AF ----
        dial = DialView(this).apply { onChange = { onDial(it) } }
        autoBtn = chip("AUTO").apply {
            textSize = 10f
            setPadding(0, 0, 0, 0)
            setOnClickListener { onAuto() }
        }
        val paramsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val order = listOf(P.EV to "EV", P.ISO to "ISO", P.SHUTTER to "S", P.WB to "WB", P.FOCUS to "AF")
        for ((p, nm) in order) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { selected = p; showDial(true); refreshDial(); refreshTabs() }
            }
            val n = TextView(this).apply {
                text = nm; textSize = 16f; setTextColor(Color.WHITE)
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            }
            val v = TextView(this).apply {
                textSize = 16f; setTextColor(Color.WHITE)
                typeface = Typeface.MONOSPACE
            }
            tabCol[p] = col; tabName[p] = n; tabValue[p] = v
            col.addView(n); col.addView(v)
            paramsRow.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }

        // ---- EXPERT pill  <->  dial row ----
        expertPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(22), 0, dp(18), 0)
            background = GradientDrawable().apply { cornerRadius = dp(26).toFloat(); setColor(0xFF1C1C1E.toInt()) }
            setOnClickListener { showDial(true); refreshDial(); refreshTabs() }
        }
        expertPill.addView(TextView(this).apply {
            text = "EXPERT"; textSize = 16f; setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE; letterSpacing = 0.08f
        })
        expertPill.addView(CrossView(this), LinearLayout.LayoutParams(dp(26), dp(26)).apply { leftMargin = dp(10) })

        val closeBtn = CrossView(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x26FFFFFF) }
            setOnClickListener { showDial(false); refreshTabs() }
        }
        dialRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        dialRow.addView(closeBtn, LinearLayout.LayoutParams(dp(36), dp(36)).apply { leftMargin = dp(14) })
        dialRow.addView(dial, LinearLayout.LayoutParams(0, dp(56), 1f))
        dialRow.addView(autoBtn, LinearLayout.LayoutParams(dp(54), dp(32)).apply { rightMargin = dp(12) })
        val pillRow = FrameLayout(this)
        pillRow.addView(expertPill, FrameLayout.LayoutParams(-2, dp(52)).apply { gravity = Gravity.CENTER })
        pillRow.addView(dialRow, FrameLayout.LayoutParams(-1, -1))

        // ---- shutter row: thumbnail | record ----
        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(0xFF1C1C1E.toInt()); setStroke(dp(1), 0x33FFFFFF)
            }
            clipToOutline = true
            setOnClickListener {
                val u = lastUri ?: return@setOnClickListener
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (e: Exception) { toast("No video player found") }
            }
        }
        recBtn = RecordButton(this).apply { setOnClickListener { toggleRecord() } }
        val shutterRow = FrameLayout(this)
        shutterRow.addView(thumb, FrameLayout.LayoutParams(dp(48), dp(48)).apply {
            gravity = Gravity.START or Gravity.CENTER_VERTICAL; leftMargin = dp(31)
        })
        shutterRow.addView(recBtn, FrameLayout.LayoutParams(dp(76), dp(76)).apply { gravity = Gravity.CENTER })

        // ---- bottom handle (opens the settings chips) ----
        val handleRow = FrameLayout(this)
        handleRow.addView(ChevronView(this).apply {
            up = true; boxed = true
            setOnClickListener { toggleSettings() }
        }, FrameLayout.LayoutParams(dp(60), dp(30)).apply { gravity = Gravity.CENTER })

        val bottomCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
        }
        bottomCol.addView(paramsRow, LinearLayout.LayoutParams(-1, dp(60)))
        bottomCol.addView(pillRow, LinearLayout.LayoutParams(-1, dp(60)))
        bottomCol.addView(shutterRow, LinearLayout.LayoutParams(-1, dp(100)))
        bottomCol.addView(handleRow, LinearLayout.LayoutParams(-1, dp(46)))
        root.addView(bottomCol, FrameLayout.LayoutParams(-1, dp(CTRL_DP)).apply { gravity = Gravity.BOTTOM })
    }

    private fun timerBg(rec: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat()
        setColor(if (rec) 0x66FF3B30 else 0x1FFFFFFF)
    }

    private fun topChip(onClick: () -> Unit): TextView {
        val c = chip("")
        c.setOnClickListener { onClick() }
        topRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        return c
    }

    private fun showOptions(anchor: View, items: List<String>, cur: Int, allowRec: Boolean = false, pick: (Int) -> Unit) {
        if (recording && !allowRec) { toast("Stop recording to change this setting"); return }
        if (optOwner === anchor && optScroll.visibility == View.VISIBLE) {
            optScroll.visibility = View.GONE; return
        }
        optOwner = anchor
        optRow.removeAllViews()
        items.forEachIndexed { i, s ->
            val c = chip(s, i == cur)
            c.setOnClickListener { optScroll.visibility = View.GONE; pick(i) }
            optRow.addView(c, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        optScroll.visibility = View.VISIBLE
    }

    private fun fmtZoom(x: Float) =
        if (abs(x - x.roundToInt()) < 0.05f) "${x.roundToInt()}" else fmt("%.1f", x)

    private fun buildLensPills() {
        if (!::lensRow.isInitialized) return
        lensRow.removeAllViews()
        if (lensOpts.isEmpty()) return
        val cur = (baseDisp[camId] ?: 1f) * zoom
        val items = ArrayList<Pair<Lens, Boolean>>()
        var found = false
        for (l in lensOpts) {
            val sel = l.id == camId && abs(l.zoom - zoom) < 0.04f
            if (sel) found = true
            items.add(l to sel)
        }
        if (!found) {
            var at = items.indexOfFirst { it.first.disp > cur }
            if (at < 0) at = items.size
            items.add(at, Lens(camId, zoom, cur) to true)
        }
        for ((l, sel) in items) {
            val t = TextView(this).apply {
                text = fmtZoom(l.disp) + (if (sel) "×" else "")
                textSize = 15f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                if (sel) background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat(); setColor(0x66000000); setStroke(dp(2), Color.WHITE)
                }
                setOnClickListener { onLensPill(l) }
            }
            lensRow.addView(t, LinearLayout.LayoutParams(if (sel) dp(56) else dp(40), dp(32)).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
    }

    private fun onLensPill(l: Lens) {
        if (l.id != camId) switchCamera(l.id, l.zoom) else setZoom(l.zoom)
    }

    private fun setZoom(z: Float) {
        val nz = z.coerceIn(zoomMin, zoomMax)
        if (abs(nz - zoom) < 0.001f) return
        zoom = nz
        buildLensPills()
        pushRequest()
    }

    private fun showDial(on: Boolean) {
        dialOpen = on
        dialRow.visibility = if (on) View.VISIBLE else View.GONE
        expertPill.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun toggleSettings() {
        val show = settingsBox.visibility != View.VISIBLE
        settingsBox.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) optScroll.visibility = View.GONE
        chevron.up = show
    }

    private fun toggleTorch() {
        if (!hasFlash) { toast("No flash on this camera"); return }
        torchOn = !torchOn
        refreshFlash()
        pushRequest()
    }

    private fun refreshFlash() {
        if (!::flashView.isInitialized) return
        flashView.on = torchOn
        flashView.alpha = if (hasFlash) 1f else 0.35f
    }

    /** Portrait layout: picture starts under the top bar; controls overlay the bottom. */
    private fun layoutPreview() {
        if (root.width <= 0 || root.height <= 0) return
        val top = dp(96)
        val availH = root.height - top - dp(CTRL_DP)
        val r = size.height.toFloat() / size.width
        var w = root.width.toFloat()
        var h = w / r
        val maxH = (root.height - top).toFloat()
        if (h > maxH) { h = maxH; w = h * r }
        var y = top.toFloat()
        if (h <= availH) y = top + (availH - h) / 2f
        val lp = FrameLayout.LayoutParams(w.roundToInt(), h.roundToInt())
        lp.leftMargin = ((root.width - w) / 2f).roundToInt()
        lp.topMargin = y.roundToInt()
        previewBox.layoutParams = lp
        textureView.post { applyTransform() }
    }

    /** The GL pipeline already outputs an upright picture; just tell it how the display is rotated. */
    private fun applyTransform() {
        textureView.setTransform(Matrix())
        gl?.previewRot = rotHint()
    }

    private fun tapFocus(x: Float, y: Float) {
        val w = previewBox.width.toFloat()
        val h = previewBox.height.toFloat()
        if (w == 0f || manualFocus || !afAvail.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) return
        var nx = (x / w).coerceIn(0f, 1f)
        var ny = (y / h).coerceIn(0f, 1f)
        val r = rotHint()
        val sx: Float
        val sy: Float
        when (r) {
            90 -> { sx = ny; sy = 1 - nx }
            180 -> { sx = 1 - nx; sy = 1 - ny }
            270 -> { sx = 1 - ny; sy = nx }
            else -> { sx = nx; sy = ny }
        }
        nx = sx; ny = sy
        val vis = cropRegion()
        val aw = vis.width()
        val ah = vis.height()
        val half = (min(aw, ah) * 0.08f).toInt()
        val cx = vis.left + (nx * aw).toInt()
        val cy = vis.top + (ny * ah).toInt()
        val rx = (cx - half).coerceIn(activeArray.left, activeArray.right - 2 * half - 1)
        val ry = (cy - half).coerceIn(activeArray.top, activeArray.bottom - 2 * half - 1)
        afRegion = MeteringRectangle(rx, ry, half * 2, half * 2, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        pushRequest()

        val lp = focusRing.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = (x - dp(32)).toInt(); lp.topMargin = (y - dp(32)).toInt()
        focusRing.layoutParams = lp
        focusRing.animate().cancel()
        focusRing.alpha = 1f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().alpha(0f).setStartDelay(700).setDuration(300)
            .withEndAction { focusRing.visibility = View.GONE }.start()
    }

    // =====================================================================
    // UI refresh helpers
    // =====================================================================
    private fun sizeLabel(s: Size): String {
        val r = s.width.toFloat() / s.height
        if (abs(r - 16f / 9f) < 0.02f) {
            return when {
                s.height >= 4320 -> "8K"
                s.height >= 2160 -> "4K"
                s.height >= 1440 -> "1440p"
                else -> "${s.height}p"
            }
        }
        return "${s.width}×${s.height}"
    }

    private fun shutLabel(ns: Long) = "1/" + (1e9 / ns).roundToInt()

    private fun focusLabel(i: Int): String {
        if (minFocusDist <= 0f) return "FIX"
        if (i == 0) return "∞"
        val m = 1f / (minFocusDist * i / 100f)
        return if (m >= 10f) fmt("%.0fm", m) else fmt("%.1fm", m)
    }

    private fun refreshTopChips() {
        chipRes.text = sizeLabel(size)
        chipFps.text = "$fps FPS"
        chipRatio.text = ratioKey
        chipCodec.text = if (hevc) "HEVC" else "H.264"
        chipBit.text = if (bitrateMbps == 0) "AUTO" else "${bitrateMbps}M"
        chipGrid.text = "GRID"; styleChip(chipGrid, grid.on)
        chipStab.text = when (stabMode) { 1 -> "OIS"; 2 -> "EIS"; else -> "STAB OFF" }
        styleChip(chipStab, stabMode != 0)
        for (c in listOf(chipRes, chipFps, chipRatio, chipCodec, chipBit)) styleChip(c, false)
        chipLog.text = if (logMode == 0) "LOG" else LOGS[logMode]; styleChip(chipLog, logMode != 0)
        chipTen.text = "10-BIT"; styleChip(chipTen, tenBit && tenBitAvail)
        chipLut.text = when (lutSel) {
            0 -> "LUT"
            1 -> "REC.709"
            else -> (lutFiles.getOrNull(lutSel - 2)?.nameWithoutExtension ?: "LUT").take(10)
        }
        styleChip(chipLut, lutSel != 0)
        if (::formatLabel.isInitialized) formatLabel.text = "${sizeLabel(size)} · $fps"
    }

    private fun isAuto(p: P) = when (p) {
        P.ISO, P.SHUTTER -> !manualExp
        P.FOCUS -> !manualFocus
        P.WB -> wbIdx == 0
        P.EV -> evIdx == -evMin
    }

    private fun refreshTabs() {
        tabValue[P.ISO]?.text = isoList.getOrNull(isoIdx)?.toString() ?: "-"
        tabValue[P.SHUTTER]?.text = shutList.getOrNull(shutIdx)?.let { shutLabel(it) } ?: "-"
        tabValue[P.FOCUS]?.text = focusLabel(focusIdx)
        tabValue[P.WB]?.text = wbOpts.getOrNull(wbIdx)?.first ?: "AUTO"
        val ev = (evMin + evIdx) * evStep
        tabValue[P.EV]?.text = if (abs(ev) < 0.05f) "0.0" else fmt("%+.1f", ev)
        for (p in P.values()) {
            val c = if (dialOpen && p == selected) ACCENT else Color.WHITE
            tabName[p]?.setTextColor(c)
            tabValue[p]?.setTextColor(c)
        }
        styleChip(autoBtn, isAuto(selected))
        dial.dimmed = selected == P.EV && manualExp
    }

    private fun refreshDial() {
        when (selected) {
            P.ISO -> dial.setup(isoList.map { it.toString() }, isoIdx, 3, 16f)
            P.SHUTTER -> dial.setup(shutList.map { shutLabel(it) }, shutIdx, 3, 20f)
            P.FOCUS -> dial.setup((0..100).map { focusLabel(it) }, focusIdx, 10, 8f)
            P.WB -> dial.setup(wbOpts.map { it.first }, wbIdx, 1, 64f)
            P.EV -> dial.setup(
                (evMin..evMax).map { fmt("%+.1f", it * evStep) }, evIdx,
                max(1, (1f / evStep).roundToInt()), 12f
            )
        }
        dial.dimmed = selected == P.EV && manualExp
    }

    // =====================================================================
    // Dial / auto-button handling
    // =====================================================================
    private fun onDial(i: Int) {
        when (selected) {
            P.ISO -> if (needManualSensor()) { isoIdx = i; manualExp = true } else { refreshDial(); return }
            P.SHUTTER -> if (needManualSensor()) { shutIdx = i; manualExp = true } else { refreshDial(); return }
            P.FOCUS -> if (minFocusDist > 0f && hasManualSensor) { focusIdx = i; manualFocus = true }
                       else { toast("Manual focus not supported by this camera"); refreshDial(); return }
            P.WB -> wbIdx = i
            P.EV -> evIdx = i
        }
        refreshTabs()
        pushRequest()
    }

    private fun needManualSensor(): Boolean {
        if (!hasManualSensor) toast("Manual exposure not supported by this camera")
        return hasManualSensor
    }

    private fun onAuto() {
        when (selected) {
            P.ISO, P.SHUTTER -> manualExp = false
            P.FOCUS -> manualFocus = false
            P.WB -> wbIdx = 0
            P.EV -> evIdx = (-evMin).coerceIn(0, max(0, evMax - evMin))
        }
        refreshDial(); refreshTabs(); pushRequest()
    }

    /** Called ~5x/s from the capture callback: follow the camera's metering while in auto. */
    private fun onMetered() {
        if (!manualExp) {
            isoIdx = nearestIso(lastIso); shutIdx = nearestShut(lastExp)
            if (selected == P.ISO) dial.setIndexSilently(isoIdx)
            if (selected == P.SHUTTER) dial.setIndexSilently(shutIdx)
        }
        if (!manualFocus && minFocusDist > 0f) {
            focusIdx = (lastFocus / minFocusDist * 100f).roundToInt().coerceIn(0, 100)
            if (selected == P.FOCUS) dial.setIndexSilently(focusIdx)
        }
        refreshTabs()
    }

    private fun nearestIso(v: Int) =
        isoList.indices.minByOrNull { abs(ln(isoList[it].toDouble() / v.coerceAtLeast(1))) } ?: 0

    private fun nearestShut(ns: Long) =
        shutList.indices.minByOrNull { abs(ln(shutList[it].toDouble() / ns.coerceAtLeast(1L))) } ?: 0

    // =====================================================================
    // Camera discovery / configuration
    // =====================================================================
    private fun initCameras() {
        try {
            val found = ArrayList<Pair<String, Float>>()
            for (id in cm.cameraIdList) {
                try {
                    val c = cm.getCameraCharacteristics(id)
                    if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
                    val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: continue
                    if (map.getOutputSizes(MediaRecorder::class.java).isNullOrEmpty()) continue
                    val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: continue
                    if (!caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
                    val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: 0f
                    val ss = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
                    val ratio = if (ss != null && f > 0f) {
                        val diag = sqrt(ss.width * ss.width + ss.height * ss.height)
                        (f * 43.27f / diag) / 24f
                    } else 1f
                    found.add(id to ratio)
                } catch (e: Exception) { /* skip broken camera */ }
            }
            if (found.isEmpty()) { toast("No usable back camera found"); return }
            found.sortBy { it.second }
            backIds = found.map { it.first }
            baseDisp = found.associate { it.first to ((max(it.second, 0.5f) * 2).roundToInt() / 2f) }
            val def = found.minByOrNull { abs(it.second - 1f) }!!.first
            loadCamera(def)
            val opts = ArrayList<Lens>()
            for (id in backIds) opts.add(Lens(id, 1f, baseDisp[id] ?: 1f))
            if (useZoomRatio) {
                // logical multi-camera: ultra-wide / tele are reached through the zoom ratio
                if (zoomMin < 0.95f && baseDisp.values.none { it < 0.95f })
                    opts.add(Lens(def, zoomMin, (zoomMin * 10).roundToInt() / 10f))
                if (zoomMax >= 2f && baseDisp.values.none { it >= 1.5f && it <= 2.5f })
                    opts.add(Lens(def, 2f, 2f))
            }
            lensOpts = opts.sortedBy { it.disp }
            buildLensPills(); refreshFlash(); refreshTopChips(); refreshTabs(); refreshDial()
            ready = true
            layoutPreview()
        } catch (e: Exception) {
            toast("Camera init failed: ${e.message}")
        }
    }

    private fun lensLabel(r: Float): String {
        val x = (max(r, 0.5f) * 2).roundToInt() / 2f
        return if (x == x.toInt().toFloat()) "${x.toInt()}x" else "${x}x"
    }

    private fun loadCamera(id: String) {
        camId = id
        val c = cm.getCameraCharacteristics(id)
        chars = c
        sensorOri = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        activeArray = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)
        isoRange = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 800)
        expRange = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 33_000_000L)
        minFocusDist = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        hasManualSensor = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
        awbAvail = c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES) ?: intArrayOf()
        afAvail = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: intArrayOf()
        val evr = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        evMin = evr?.lower ?: 0
        evMax = evr?.upper ?: 0
        evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0.33f
        if (evStep <= 0f) evStep = 0.33f
        fpsRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: arrayOf(Range(30, 30))
        useZoomRatio = false
        zoomMin = 1f
        var zmax = min(c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f, 10f)
        if (Build.VERSION.SDK_INT >= 30) {
            val zr = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (zr != null && zr.lower > 0f && zr.upper >= zr.lower) {
                useZoomRatio = true
                zoomMin = zr.lower
                zmax = min(zr.upper, 10f)
            }
        }
        zoomMax = max(zmax, zoomMin)
        hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        hasOis = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
            ?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true
        hasEis = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            ?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
        // OIS is on by default (the old build forced it OFF); keep user's choice if still valid
        stabMode = when {
            stabMode == 2 && hasEis -> 2
            stabMode == 0 -> 0
            stabMode == 1 && hasOis -> 1
            hasOis -> 1
            else -> 0
        }
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        allSizes = map.getOutputSizes(SurfaceTexture::class.java)
            .filter { min(it.width, it.height) >= 480 && it.width >= it.height }

        // reset per-camera manual state
        manualFocus = false; afRegion = null; zoom = 1f.coerceIn(zoomMin, zoomMax); wbIdx = 0
        evIdx = (-evMin).coerceIn(0, max(0, evMax - evMin))

        ratioList = RATIOS.filter { (_, r) -> allSizes.any { abs(it.width.toFloat() / it.height - r) < 0.02f } }
            .map { it.first }
        if (ratioList.isEmpty()) ratioList = listOf("16:9")
        if (ratioKey !in ratioList) ratioKey = ratioList.first()
        applyRatio(ratioKey)
        rebuildLists()
    }

    private fun applyRatio(key: String) {
        ratioKey = key
        val r = RATIOS.first { it.first == key }.second
        var list = allSizes.filter { abs(it.width.toFloat() / it.height - r) < 0.02f }
        if (list.isEmpty()) list = allSizes
        sizes = list.sortedByDescending { it.width.toLong() * it.height }
        val h = size.height
        size = sizes.minByOrNull { abs(it.height - h) } ?: sizes.first()
        refreshFpsOptions()
        pickPreviewSize()
    }

    private fun fpsKey(f: Int) = "$camId ${size.width}x${size.height} $f"

    /** True if some AVC/HEVC encoder on the device can do this size at this rate. */
    private fun encoderOk(w: Int, h: Int, f: Int): Boolean {
        return try {
            var any = false
            for (ci in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
                if (!ci.isEncoder) continue
                for (mime in listOf("video/avc", "video/hevc")) {
                    if (ci.supportedTypes.none { it.equals(mime, true) }) continue
                    val vc = ci.getCapabilitiesForType(mime).videoCapabilities ?: continue
                    any = true
                    if (vc.areSizeAndRateSupported(w, h, f.toDouble())) return true
                }
            }
            !any
        } catch (e: Exception) { true }
    }

    /**
     * A rate is offered when the camera advertises an AE fps range that covers it and an encoder can take it.
     * The stream-map min-frame-duration is NOT used any more: many phones list 33 ms there even though
     * they run 60 fps through the AE range, which is why 60 never showed up.
     * Combos that fail to configure are remembered in [badFps] and fall back automatically.
     */
    private fun refreshFpsOptions() {
        fpsOptions = listOf(24, 25, 30, 48, 50, 60).filter { f ->
            fpsRanges.any { it.lower <= f && f <= it.upper } &&
                fpsKey(f) !in badFps && encoderOk(size.width, size.height, f)
        }
        if (fpsOptions.isEmpty()) fpsOptions = listOf(30)
        if (fps !in fpsOptions) fps = fpsOptions.minByOrNull { abs(it - fps) }!!
    }

    private fun pickPreviewSize() {
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val r = size.width.toFloat() / size.height
        previewSize = map.getOutputSizes(SurfaceTexture::class.java)
            .filter { abs(it.width.toFloat() / it.height - r) < 0.02f && it.width <= 1920 }
            .maxByOrNull { it.width.toLong() * it.height } ?: size
    }

    private fun rebuildLists() {
        val oldNs = shutList.getOrNull(shutIdx) ?: lastExp
        val oldIso = isoList.getOrNull(isoIdx) ?: lastIso
        isoList = ISO_STOPS.filter { it >= isoRange.lower && it <= isoRange.upper }
        if (isoList.isEmpty()) isoList = listOf(isoRange.lower)
        val frameNs = (1e9 / fps).toLong()
        shutList = SHUT_DENOMS.map { (1e9 / it).toLong() }
            .filter { it >= expRange.lower && it <= expRange.upper && it <= frameNs + 1000 }
        if (shutList.isEmpty()) shutList = listOf(expRange.lower.coerceAtMost(frameNs))
        isoIdx = nearestIso(oldIso)
        shutIdx = nearestShut(oldNs)

        val wb = ArrayList<Pair<String, Int>>()
        wb.add("AUTO" to CameraMetadata.CONTROL_AWB_MODE_AUTO)
        listOf(
            "2850K" to CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
            "4000K" to CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT,
            "5500K" to CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT,
            "6500K" to CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
            "7500K" to CameraMetadata.CONTROL_AWB_MODE_SHADE
        ).forEach { if (awbAvail.contains(it.second)) wb.add(it) }
        wbOpts = wb
        if (wbIdx >= wb.size) wbIdx = 0
        zoom = zoom.coerceIn(zoomMin, zoomMax)
    }

    private fun onVideoConfigChanged() {
        refreshFpsOptions(); pickPreviewSize(); rebuildLists()
        layoutPreview(); refreshTopChips(); refreshTabs(); refreshDial()
        startPreview()
    }

    private fun onFpsChanged() {
        rebuildLists(); refreshTopChips(); refreshTabs(); refreshDial(); pushRequest()
    }

    private fun switchCamera(id: String, z: Float = 1f) {
        if (recording) { toast("Stop recording to switch lens"); return }
        if (id == camId) return
        closeCamera()
        loadCamera(id)
        zoom = z.coerceIn(zoomMin, zoomMax)
        buildLensPills(); refreshFlash(); refreshTopChips(); refreshTabs(); refreshDial(); layoutPreview()
        ui.postDelayed({ if (active) openCamera() }, 150)
    }

    // =====================================================================
    // Camera2 plumbing
    // =====================================================================
    private fun openCamera() {
        if (!hasPerms() || !textureView.isAvailable || opening || device != null) return
        opening = true
        val token = ++openGen
        try {
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) {
                    if (token == openGen) opening = false
                    if (!active || token != openGen) { c.close(); return }
                    device = c
                    startPreview()
                }
                override fun onDisconnected(c: CameraDevice) {
                    if (token == openGen) { opening = false; device = null }
                    c.close()
                }
                override fun onError(c: CameraDevice, e: Int) {
                    if (token == openGen) { opening = false; device = null }
                    c.close()
                    toast("Camera error $e")
                }
            }, bg)
        } catch (e: Exception) {
            opening = false
            toast("Cannot open camera: ${e.message}")
        }
    }

    @Synchronized
    private fun closeCamera() {
        openGen++
        opening = false
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        gl?.release()
        gl = null
        previewSurface = null
        reqBuilder = null
        torchOn = false
        refreshFlash()
    }

    @Synchronized
    private fun startPreview() {
        val dev = device ?: return
        val tex = textureView.surfaceTexture ?: return
        try {
            try { session?.close() } catch (e: Exception) {}
            session = null
            gl?.release()
            gl = null
            val g = GlPipeline()
            val cs = g.start(tex, size.width, size.height, tenBit && tenBitAvail)
            if (cs == null) { g.release(); toast("OpenGL init failed"); return }
            if (tenBit && tenBitAvail && !g.tenBitActive) toast("10-bit surface not available, using 8-bit")
            gl = g
            previewSurface = cs
            applyGlState()
            dev.createCaptureSession(listOf(cs), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    if (device == null) return
                    session = s
                    try {
                        val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        b.addTarget(cs)
                        applyControls(b)
                        reqBuilder = b
                        s.setRepeatingRequest(b.build(), captureCb, bg)
                    } catch (e: Exception) { toast("Preview error: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    ui.post {
                        if (fps > 30 && active && device != null) {
                            badFps.add(fpsKey(fps))
                            val old = fps
                            refreshFpsOptions()
                            toast("$old fps not supported here, using $fps fps")
                            onFpsChanged()
                            startPreview()
                        } else toast("Camera can't stream this resolution / fps combination")
                    }
                }
            }, bg)
        } catch (e: Exception) {
            toast("Preview error: ${e.message}")
        }
    }

    /** Pushes log / LUT / orientation settings into the GL pipeline. */
    private fun applyGlState() {
        val g = gl ?: return
        g.curve = logMode
        g.viewMode = when {
            lutSel == 1 -> 1
            lutSel >= 2 && lutCache != null -> 2
            else -> 0
        }
        g.previewRot = rotHint()
        lutCache?.let { g.setLut(it) }
    }

    private fun setLog(i: Int) {
        logMode = i
        if (i != 0 && lutSel == 0) lutSel = 1
        if (i != 0 && !tenBit && tenBitAvail) {
            tenBit = true; hevc = true
            toast("10-bit enabled for log recording")
            refreshTopChips(); startPreview()
            return
        }
        refreshTopChips(); applyGlState()
    }

    private fun refreshLutFiles() {
        lutFiles = lutDir.listFiles { f -> f.extension.equals("cube", true) }
            ?.sortedBy { it.name.lowercase(Locale.US) } ?: emptyList()
    }

    private fun selectLut(i: Int) {
        lutSel = i
        if (i >= 2) {
            val f = lutFiles.getOrNull(i - 2)
            if (f == null) { lutSel = 0 } else {
                Thread {
                    try {
                        val d = CubeLut.parse(f)
                        runOnUiThread { lutCache = d; applyGlState(); refreshTopChips() }
                    } catch (e: Exception) {
                        runOnUiThread { toast("Invalid LUT: ${e.message}"); lutSel = 0; applyGlState(); refreshTopChips() }
                    }
                }.start()
                refreshTopChips()
                return
            }
        }
        refreshTopChips(); applyGlState()
    }

    private fun importLut() {
        if (recording) { toast("Import LUTs before recording, then switch freely while recording"); return }
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 77)
        } catch (e: Exception) { toast("No file picker available") }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        Thread {
            var out: File? = null
            try {
                var name = "lut.cube"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ix >= 0 && c.moveToFirst()) name = c.getString(ix) ?: name
                }
                name = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
                if (!name.endsWith(".cube", true)) name += ".cube"
                lutDir.mkdirs()
                val f = File(lutDir, name)
                out = f
                contentResolver.openInputStream(uri)!!.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                val d = CubeLut.parse(f)
                runOnUiThread {
                    refreshLutFiles()
                    val idx = lutFiles.indexOfFirst { it.name == f.name }
                    lutCache = d
                    lutSel = if (idx >= 0) idx + 2 else 0
                    applyGlState(); refreshTopChips()
                }
            } catch (e: Exception) {
                out?.delete()
                toast("LUT import failed: ${e.message}")
            }
        }.start()
    }

    private val captureCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            res.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
            res.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastExp = it }
            res.get(CaptureResult.LENS_FOCUS_DISTANCE)?.let { lastFocus = it }
            if (++frameCount % 6 == 0) ui.post { onMetered() }
        }
    }

    private fun pickFpsRange(f: Int): Range<Int> =
        fpsRanges.firstOrNull { it.lower == f && it.upper == f }
            ?: fpsRanges.filter { it.lower <= f && f <= it.upper }
                .minByOrNull { abs(it.upper - f) * 2 + abs(it.lower - f) }
            ?: Range(f, f)

    private fun cropRegion(): Rect {
        val z = zoom
        if (z <= 1f) return Rect(activeArray)
        val w = (activeArray.width() / z).toInt()
        val h = (activeArray.height() / z).toInt()
        val l = activeArray.left + (activeArray.width() - w) / 2
        val t = activeArray.top + (activeArray.height() - h) / 2
        return Rect(l, t, l + w, t + h)
    }

    private fun applyControls(b: CaptureRequest.Builder) {
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pickFpsRange(fps))

        if (manualExp && hasManualSensor) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoList[isoIdx.coerceIn(0, isoList.lastIndex)])
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, shutList[shutIdx.coerceIn(0, shutList.lastIndex)])
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, (1e9 / fps).toLong())
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evMin + evIdx)
        }

        if (manualFocus && minFocusDist > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocusDist * focusIdx / 100f)
        } else if (afAvail.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
            afRegion?.let { b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(it)) }
        }

        wbOpts.getOrNull(wbIdx)?.let { b.set(CaptureRequest.CONTROL_AWB_MODE, it.second) }
        if (useZoomRatio) {
            if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoom)
        } else b.set(CaptureRequest.SCALER_CROP_REGION, cropRegion())
        if (hasFlash) b.set(
            CaptureRequest.FLASH_MODE,
            if (torchOn) CameraMetadata.FLASH_MODE_TORCH else CameraMetadata.FLASH_MODE_OFF
        )

        // EIS and OIS are mutually exclusive (most HALs ignore OIS while EIS is on)
        if (hasEis) b.set(
            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
            if (stabMode == 2) CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON else CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
        )
        if (hasOis) b.set(
            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
            if (stabMode == 1) CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
        )
    }

    private fun pushRequest() { bg.post { updateRepeating() } }

    private fun updateRepeating() {
        val s = session ?: return
        val b = reqBuilder ?: return
        try {
            applyControls(b)
            s.setRepeatingRequest(b.build(), captureCb, bg)
        } catch (e: Exception) { /* session closing */ }
    }

    // =====================================================================
    // Recording
    // =====================================================================
    private fun dispDeg() = when (windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> 90
        Surface.ROTATION_180 -> 180
        Surface.ROTATION_270 -> 270
        else -> 0
    }

    private fun rotHint() = (sensorOri - dispDeg() + 360) % 360

    /** Orientation tag for the file: follows how the phone is held (UI is locked to portrait). */
    private fun recRot() = (sensorOri + devDeg) % 360

    private fun currentBitrate(): Int {
        if (bitrateMbps > 0) return bitrateMbps * 1_000_000
        val bpp = if (hevc) 0.14 else 0.2
        return (size.width.toLong() * size.height * fps * bpp).toLong()
            .coerceIn(8_000_000L, 200_000_000L).toInt()
    }

    private fun toggleRecord() {
        if (recording) stopRecording() else startRecording()
    }

    private fun openOutput(): Pair<FileDescriptor?, String?> {
        val name = "PRO_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        pendingUri = null; pendingPfd = null; pendingFile = null
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("Cannot create file")
            pendingUri = uri
            val pfd = contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("Cannot open file")
            pendingPfd = pfd
            return Pair(pfd.fileDescriptor, null)
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "ProCam")
        dir.mkdirs()
        val f = File(dir, name)
        pendingFile = f
        return Pair(null, f.absolutePath)
    }

    private fun finishOutput(ok: Boolean) {
        try { pendingPfd?.close() } catch (e: Exception) {}
        pendingPfd = null
        if (Build.VERSION.SDK_INT >= 29) {
            val uri = pendingUri
            if (uri != null) {
                if (ok) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(uri, v, null, null)
                    lastUri = uri
                    loadThumb(uri)
                } else contentResolver.delete(uri, null, null)
            }
        } else {
            val f = pendingFile
            if (f != null) {
                if (ok) MediaScannerConnection.scanFile(this, arrayOf(f.absolutePath), arrayOf("video/mp4"), null)
                else f.delete()
            }
        }
        pendingUri = null; pendingFile = null
        if (ok) toast("Saved to Movies/ProCam")
    }

    private fun loadThumb(uri: Uri) {
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bmp = contentResolver.loadThumbnail(uri, Size(256, 256), null)
                runOnUiThread { thumb.setImageBitmap(bmp) }
            } catch (e: Exception) { /* no thumbnail */ }
        }.start()
    }

    private fun loadLastThumb() {
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Video.Media._ID),
                    MediaStore.Video.Media.RELATIVE_PATH + " LIKE ?", arrayOf("Movies/ProCam%"),
                    MediaStore.Video.Media.DATE_ADDED + " DESC"
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                        lastUri = uri
                        loadThumb(uri)
                    }
                }
            } catch (e: Exception) { /* ignore */ }
        }.start()
    }

    private fun startRecording() {
        val g = gl ?: return
        if (device == null || session == null) return
        val audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ten = tenBit && tenBitAvail && g.tenBitActive
        val r: Recorder = try {
            val out = openOutput()
            Recorder(out.first, out.second, size.width, size.height, fps, currentBitrate(),
                hevc || ten, ten, logMode == 3, recRot(), audio)
        } catch (e: Exception) {
            toast("Recorder error: ${e.message}")
            finishOutput(false)
            return
        }
        try {
            val surf = r.prepare()
            r.start()
            if (!g.startEncoding(surf, size.width, size.height, r.wallBase)) {
                throw IllegalStateException("encoder surface unavailable")
            }
            rec = r
            recording = true
            recStart = SystemClock.elapsedRealtime()
            onRecordingChanged()
        } catch (e: Exception) {
            try { g.stopEncoding() } catch (x: Exception) {}
            try { r.finish() } catch (x: Exception) {}
            finishOutput(false)
            if (ten) {
                tenBit = false
                toast("10-bit recording failed on this device, switched to 8-bit")
                refreshTopChips(); startPreview()
            } else toast("Cannot start recording: ${e.message}")
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        gl?.stopEncoding()
        val ok = try { rec?.finish() ?: false } catch (e: Exception) { false }
        rec = null
        finishOutput(ok)
        onRecordingChanged()
    }

    private val timerTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            timerText.text = if (s >= 3600) fmt("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
                             else fmt("%02d:%02d", s / 60, s % 60)
            ui.postDelayed(this, 250)
        }
    }

    private fun onRecordingChanged() {
        recBtn.recording = recording
        timerText.background = timerBg(recording)
        val a = if (recording) 0.35f else 1f
        for (c in listOf(chipRes, chipFps, chipRatio, chipCodec, chipBit, chipStab, chipLog, chipTen)) c.alpha = a
        timerText.visibility = if (recording) View.VISIBLE else View.INVISIBLE
        if (recording) { optScroll.visibility = View.GONE; ui.post(timerTick) } else timerText.text = "00:00"
    }
}
