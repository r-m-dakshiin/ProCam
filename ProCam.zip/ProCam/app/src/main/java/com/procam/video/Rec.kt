package com.procam.video

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.SystemClock
import android.view.Surface
import java.io.FileDescriptor
import java.util.concurrent.atomic.AtomicLong

/**
 * Encodes the GL output (video) plus microphone (audio) into an MP4.
 * Video comes from a MediaCodec input surface fed by [GlPipeline].
 */
class Recorder(
    private val fd: FileDescriptor?,
    private val path: String?,
    private val w: Int,
    private val h: Int,
    private val fps: Int,
    private val bitrate: Int,
    private val hevc: Boolean,
    private val tenBit: Boolean,
    private val hlg: Boolean,
    private val rotation: Int,
    private val withAudio: Boolean
) {
    /** Wall-clock (elapsedRealtime ns) of the first encoded video frame; set by the GL thread. */
    val wallBase = AtomicLong(0)

    private var vCodec: MediaCodec? = null
    private var aCodec: MediaCodec? = null
    private var audioRec: AudioRecord? = null
    private var channels = 1
    private var mux: MediaMuxer? = null
    private var expected = 1
    private var added = 0
    private var muxStarted = false
    private val lock = java.lang.Object()
    @Volatile private var stopping = false
    @Volatile private var failed = false
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    private val rate = 48000

    fun prepare(): Surface {
        val mime = if (hevc) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        val f = MediaFormat.createVideoFormat(mime, w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        f.setInteger(MediaFormat.KEY_PRIORITY, 0)
        f.setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
        if (tenBit) f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10)
        if (hlg) {
            f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT2020)
            f.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_HLG)
            f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        }
        val c = MediaCodec.createEncoderByType(mime)
        vCodec = c
        c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = c.createInputSurface()

        var audioOk = false
        if (withAudio) audioOk = setupAudio()
        expected = if (audioOk) 2 else 1

        val m = if (fd != null) MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                else MediaMuxer(path!!, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        m.setOrientationHint(rotation)
        mux = m
        return surface
    }

    private fun setupAudio(): Boolean {
        try {
            for (src in intArrayOf(MediaRecorder.AudioSource.CAMCORDER, MediaRecorder.AudioSource.MIC)) {
                for (ch in intArrayOf(AudioFormat.CHANNEL_IN_STEREO, AudioFormat.CHANNEL_IN_MONO)) {
                    val min = AudioRecord.getMinBufferSize(rate, ch, AudioFormat.ENCODING_PCM_16BIT)
                    if (min <= 0) continue
                    val ar = AudioRecord(src, rate, ch, AudioFormat.ENCODING_PCM_16BIT, min * 4)
                    if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); continue }
                    channels = if (ch == AudioFormat.CHANNEL_IN_STEREO) 2 else 1
                    val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, channels)
                    af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    af.setInteger(MediaFormat.KEY_BIT_RATE, if (channels == 2) 192000 else 128000)
                    af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                    val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                    c.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    aCodec = c
                    audioRec = ar
                    return true
                }
            }
        } catch (e: Exception) { /* no audio */ }
        return false
    }

    fun start() {
        vCodec!!.start()
        vThread = Thread { try { drainVideo() } catch (e: Exception) { failed = true } }.also { it.start() }
        if (audioRec != null && aCodec != null) {
            aCodec!!.start()
            aThread = Thread { try { audioLoop() } catch (e: Exception) { failed = true } }.also { it.start() }
        }
    }

    private fun addTrack(f: MediaFormat): Int = synchronized(lock) {
        val i = mux!!.addTrack(f)
        added++
        if (added == expected) { mux!!.start(); muxStarted = true; lock.notifyAll() }
        i
    }

    private fun awaitMux(): Boolean {
        synchronized(lock) {
            var n = 0
            while (!muxStarted && n < 50) { lock.wait(100); n++ }
            return muxStarted
        }
    }

    private fun write(track: Int, buf: java.nio.ByteBuffer, info: MediaCodec.BufferInfo) {
        synchronized(lock) { if (muxStarted) mux!!.writeSampleData(track, buf, info) }
    }

    private fun drainVideo() {
        val c = vCodec!!
        val info = MediaCodec.BufferInfo()
        var track = -1
        while (true) {
            val i = c.dequeueOutputBuffer(info, 10_000)
            if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = addTrack(c.outputFormat)
            } else if (i >= 0) {
                val buf = c.getOutputBuffer(i)
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && buf != null && track >= 0) {
                    if (awaitMux()) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        write(track, buf, info)
                    } else failed = true
                }
                c.releaseOutputBuffer(i, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
            }
        }
    }

    private fun audioLoop() {
        val ar = audioRec!!
        val c = aCodec!!
        val info = MediaCodec.BufferInfo()
        // wait for the first video frame so both tracks share a time base
        var waited = 0
        while (wallBase.get() == 0L && !stopping && waited < 600) { Thread.sleep(5); waited++ }
        if (wallBase.get() == 0L) { failed = true; return }
        ar.startRecording()
        var track = -1
        var startUs = -1L
        var frames = 0L
        var eosSent = false
        val frameBytes = 2 * channels
        while (true) {
            if (!eosSent) {
                val ii = c.dequeueInputBuffer(5_000)
                if (ii >= 0) {
                    val ib = c.getInputBuffer(ii)!!
                    ib.clear()
                    val n = maxOf(0, ar.read(ib, minOf(ib.capacity(), 4096 * channels)))
                    val chunkUs = n / frameBytes * 1_000_000L / rate
                    if (startUs < 0) {
                        val nowUs = (SystemClock.elapsedRealtimeNanos() - wallBase.get()) / 1000
                        startUs = maxOf(0L, nowUs - chunkUs)
                    }
                    val pts = startUs + frames * 1_000_000L / rate
                    frames += n / frameBytes
                    if (stopping) {
                        c.queueInputBuffer(ii, 0, n, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        eosSent = true
                    } else {
                        c.queueInputBuffer(ii, 0, n, pts, 0)
                    }
                }
            }
            var done = false
            while (true) {
                val oi = c.dequeueOutputBuffer(info, if (eosSent) 10_000 else 0)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = addTrack(c.outputFormat)
                } else if (oi >= 0) {
                    val buf = c.getOutputBuffer(oi)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && buf != null && track >= 0 && awaitMux()) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        write(track, buf, info)
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) { done = true; break }
                } else break
            }
            if (done) break
        }
    }

    /** Stops everything and finalizes the file. Returns true when a playable file was written. */
    fun finish(): Boolean {
        stopping = true
        try { vCodec?.signalEndOfInputStream() } catch (e: Exception) { failed = true }
        try { vThread?.join(4000) } catch (e: Exception) {}
        try { aThread?.join(4000) } catch (e: Exception) {}
        try { audioRec?.stop() } catch (e: Exception) {}
        try { audioRec?.release() } catch (e: Exception) {}
        try { vCodec?.stop() } catch (e: Exception) {}
        try { vCodec?.release() } catch (e: Exception) {}
        try { aCodec?.stop() } catch (e: Exception) {}
        try { aCodec?.release() } catch (e: Exception) {}
        var ok = !failed
        synchronized(lock) {
            try { if (muxStarted) mux?.stop() else ok = false } catch (e: Exception) { ok = false }
            try { mux?.release() } catch (e: Exception) {}
        }
        vCodec = null; aCodec = null; audioRec = null; mux = null
        return ok
    }
}
