package com.procam.video

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Rule-of-thirds grid drawn over the preview. */
class GridOverlay(ctx: Context) : View(ctx) {
    private val p = Paint().apply {
        color = 0x66FFFFFF.toInt()
        strokeWidth = 1f * ctx.resources.displayMetrics.density
    }
    var on = false
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        if (!on) return
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            c.drawLine(w * i / 3, 0f, w * i / 3, h, p)
            c.drawLine(0f, h * i / 3, w, h * i / 3, p)
        }
    }
}

/** Round record / stop button with a smooth circle <-> rounded-square morph. */
class RecordButton(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 3.5f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF3B30.toInt() }
    private var t = 0f
    private var anim: ValueAnimator? = null
    var recording = false
        set(v) {
            if (field == v) return
            field = v
            anim?.cancel()
            anim = ValueAnimator.ofFloat(t, if (v) 1f else 0f).apply {
                duration = 220
                addUpdateListener { t = it.animatedValue as Float; invalidate() }
                start()
            }
        }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 3f * d
        c.drawCircle(cx, cy, r, ring)
        val half = r * (0.76f - 0.36f * t)
        val corner = half + (7f * d - half) * t
        c.drawRoundRect(cx - half, cy - half, cx + half, cy + half, corner, corner, fill)
    }
}

/**
 * Horizontal "ruler" dial like the pro-mode wheels on Samsung / OnePlus.
 * Drag or fling to change value; reports the new index through [onChange].
 */
class DialView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private var labels: List<String> = emptyList()
    private var major = 1
    private var spacing = 14f * d
    private var pos = 0f
    private var lastIdx = -1
    private var dragging = false
    private var anim: ValueAnimator? = null
    private var lastX = 0f
    private var vt: VelocityTracker? = null

    var onChange: ((Int) -> Unit)? = null
    var dimmed = false
        set(v) { field = v; invalidate() }

    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * d; textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }
    private val markP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFC400.toInt(); strokeWidth = 2.5f * d; strokeCap = Paint.Cap.ROUND
    }

    fun setup(l: List<String>, index: Int, majorEvery: Int, spacingDp: Float) {
        anim?.cancel()
        dragging = false
        labels = l
        major = max(1, majorEvery)
        spacing = spacingDp * d
        pos = index.coerceIn(0, max(0, l.size - 1)).toFloat()
        lastIdx = pos.roundToInt()
        invalidate()
    }

    /** Move the dial without firing [onChange] (used while auto-exposure follows the scene). */
    fun setIndexSilently(i: Int) {
        if (dragging || labels.isEmpty()) return
        pos = i.coerceIn(0, labels.size - 1).toFloat()
        lastIdx = pos.roundToInt()
        invalidate()
    }

    private fun notifyIdx() {
        val i = pos.roundToInt()
        if (i != lastIdx) {
            lastIdx = i
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(i)
        }
    }

    private fun moveBy(delta: Float) {
        if (labels.isEmpty()) return
        pos = (pos + delta).coerceIn(0f, (labels.size - 1).toFloat())
        notifyIdx()
        invalidate()
    }

    private fun fling(v: Float) {
        val n = labels.size
        if (n == 0) { dragging = false; return }
        val target = (pos - v * 0.15f / spacing).roundToInt().coerceIn(0, n - 1).toFloat()
        val dist = abs(target - pos)
        if (dist < 0.01f) {
            pos = target; dragging = false; notifyIdx(); invalidate(); return
        }
        anim = ValueAnimator.ofFloat(pos, target).apply {
            duration = (120 + dist * 14).toLong().coerceAtMost(700L)
            interpolator = DecelerateInterpolator()
            addUpdateListener { pos = it.animatedValue as Float; notifyIdx(); invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    dragging = false
                    pos = pos.roundToInt().toFloat()
                    notifyIdx()
                    invalidate()
                }
            })
            start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                dragging = true
                lastX = e.x
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.x - lastX
                lastX = e.x
                moveBy(-dx / spacing)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val v = vt?.xVelocity ?: 0f
                vt?.recycle(); vt = null
                fling(v)
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0 || width == 0) return
        val cx = width / 2f
        val first = max(0, floor(pos - cx / spacing).toInt())
        val last = min(n - 1, ceil(pos + cx / spacing).toInt())
        val maxA = if (dimmed) 90 else 255
        val top = 10f * d
        for (i in first..last) {
            val x = cx + (i - pos) * spacing
            val a = ((1f - abs(x - cx) / cx).coerceIn(0f, 1f) * maxA).toInt()
            val isMajor = i % major == 0
            tickP.color = Color.WHITE
            tickP.alpha = if (isMajor) a else (a * 0.55f).toInt()
            c.drawLine(x, top, x, top + (if (isMajor) 18f else 9f) * d, tickP)
            if (isMajor) {
                textP.color = Color.WHITE
                textP.alpha = (a * 0.85f).toInt()
                c.drawText(labels[i], x, top + 36f * d, textP)
            }
        }
        markP.alpha = maxA
        c.drawLine(cx, 2f * d, cx, top + 22f * d, markP)
        c.drawCircle(cx, 2f * d, 2.5f * d, markP)
    }
}
